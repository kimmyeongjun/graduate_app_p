package com.example.pive;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import android.os.AsyncTask;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.mobileconnectors.s3.transfermanager.Download;
import com.amazonaws.mobileconnectors.s3.transfermanager.TransferManager;
import com.amazonaws.mobileconnectors.s3.transfermanager.Upload;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public class ServerControlMethod {
	public static final AWSCredentials credential = new BasicAWSCredentials(
			"AKIAJ7ZFAQV3YV6ZCDTA", "Wx/2bOW9Ypn3S9hA/3yZcqUOinF5QmnJcQ5eXZXw");
	public static final TransferManager tm = new TransferManager(credential);
	public static final String bucketName = "piveapp";
	//public static final String bucketDirName = "detail_profile_xml";
	String[] keys;
	String path;

	public Boolean fileUpload(String dirpath, String filename,String kind) {
		String fin = "";
		try {
			fin = new FilePut().execute(dirpath, filename,kind).get();

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (fin == "finish")
			return true;
		else
			return false;
	}

	public Boolean fileDownload(String dirpath, String filename,String kind) {
		String fin = "";
		try {
			fin = new FileGet().execute(dirpath, filename,kind).get();

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (fin == "finish")
			return true;
		else
			return false;
	}

	public Boolean allFileDownload(String dirpath, Vector<Person> person) {
		String fin = "";
		String fileName;

		try {
			for (int i = 0; i < person.size(); i++) {
				fileName = "/" + person.get(i).getNumber() + ".xml";
				fin = new FileGet().execute(dirpath, fileName ).get();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (fin.equals("finish"))
			return true;
		else
			return false;
	}
	
	public boolean syncPhoto(String dirpath, ArrayList<String> canSyncKey) {
		String fin = "";
		try {
			this.path = dirpath;
			fin = new photoget().execute(canSyncKey).get();

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (fin == "finish")
			return true;
		else
			return false;
	}
	
	public String[] getkey() {
		String fin = "";
		
		try {
			fin = new KeysGet().execute().get();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (fin.equals("finish"))
			return keys;
		else
			return null;
		
	}

	/*
	 * public Boolean fileDownloadAllKey(String dirpath, String filename) {
	 * String fin = ""; try { fin = new FileGet().execute(dirpath,
	 * filename).get();
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } if(fin == "finish") return
	 * true; else return false; }
	 */

	// 파일 업로드용
	public class FilePut extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			File muploadfile = new File(params[0] + params[1]);
			Upload upload = tm.upload(bucketName, params[2] + params[1],
					muploadfile);

			// 업로드 진행
			try {
				upload.waitForCompletion();
			} catch (Exception e) {
				e.printStackTrace();
				return e.toString();
			}
			return "finish";
		}
	}

	// 파일 다운로드용
	public class FileGet extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			// 다운로드 진행
			try {
				File mDownloadfile = new File(params[0] + params[1]);
				Download download = tm.download(bucketName, params[2]
						+ params[1], mDownloadfile);
				download.waitForCompletion();
			} catch (Exception e) {
				e.printStackTrace();
				return e.toString();
			}
			return "finish";
		}
	}
	
	public class KeysGet extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... params) {
			// 다운로드 진행
			try {
				AmazonS3Client mClient = new AmazonS3Client(credential);				
				List<S3ObjectSummary> summaries = mClient.listObjects(bucketName).getObjectSummaries();
								
				keys = new String[summaries.size()];
				
				for(int i = 0; i < keys.length; i++) {
					keys[i] = summaries.get(i).getKey();
				}
					
			} catch (Exception e) {
				e.printStackTrace();
				return e.toString();
			}
			return "finish";
		}
	}
	
	public class photoget extends AsyncTask<ArrayList<String>, Void, String> {

		@Override
		protected String doInBackground(ArrayList<String>... params) {
			// 다운로드 진행
			try {
				for(int i=0;i<params[0].size();i++) {
					File mDownloadfile = new File(path+"/"+params[0].get(i).toString()+".jpg");
					Download download = tm.download(bucketName, "profile/"+params[0].get(i).toString()+".jpg", mDownloadfile);
					download.waitForCompletion();
				}
			} catch (Exception e) {
				e.printStackTrace();
				return e.toString();
			}
			return "finish";
		}
	}

}
