package com.example.pive;

import java.util.Vector;

class Person {
	private String Name;
	private String Number;
	private Vector<Group> group = new Vector<Group>();
	private boolean isChecked = false;

	public Person(String _Name, String _Number) {
		this.Name = _Name;
		this.Number = _Number;
	}

	public String getName() {
		return Name;
	}

	public String getNumber() {
		return Number;
	}

	public void addGroup(Group group) {
		this.group.add(group);
	}

	public Vector<Group> getGroup() {
		return group;
	}

	public void check() {
		if (isChecked) {
			isChecked = false;
		} else
			isChecked = true;
	}
	
	public boolean isChecked() {
		return isChecked;
	}
	
	public void init_check() {
		isChecked = false;
		
	}
}