﻿package com.example.pive;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore.Images;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.android.integration.IntentIntegrator;
import com.kakao.KakaoLink;
import com.kakao.KakaoParameterException;
import com.kakao.KakaoTalkLinkMessageBuilder;

public class MainActivity extends Activity {
	public enum theme {
		white, circle, blackboard, black, brick, note, note2, paint, pino, rainbow, tree
	}

	boolean question = false;
	LinearLayout main_layout;
	boolean addgroup = false;

	ImageView trash;
	// 튜토리얼
	String str_dist = "";
	int dist[] = { 0, 0, 0, 0 };
	boolean tutorial0 = false;
	boolean tutorial1 = false;
	boolean tutorial2 = false;
	boolean tutorial3 = false;

	Typeface font;
	boolean group = false;

	// SMS보내기
	ImageView smsImage;

	// qr코드부분

	ImageView myQRCodeImage;
	ImageView qr_image;

	boolean openWeb = false;
	boolean onDoTake = false;
	boolean onQr = false;

	// 뒤로가기 부분
	boolean view_my_profile = false;
	boolean view_other_profile = false;
	boolean view_modify_profile = false;
	boolean view_modify_background = false;
	boolean view_qrcode = false;
	boolean view_my_picture = false;
	boolean view_other_picture = false;

	int checkprofile = 0;
	String otherName = "";
	String otherPhoneNumber = "";

	// ///// profile 제작
	Vector<LinearLayout> vector_EditTextLayout;
	Vector<EditText[]> vector_EditText;
	Vector<TextView[]> vector_TextView;
	RelativeLayout detail_profile;
	AddEditTextLayout addEditTextLayout;
	FileOutputStream fout;
	FrameLayout profile_modify_frameLayout;
	LinearLayout profile;
	LinearLayout profile_modify;
	FrameLayout profile_frame;
	FrameLayout profile_modify_frame;
	ImageView profile_modify_plusImage;
	RelativeLayout detail_modify_profile;

	ServerControlMethod serverControlMethod;
	boolean downCheck;

	ImageView syncPhoto;

	String dirPath;
	// /////
	String myName;
	String myPhoneNumber;
	String mythemeName;
	int mytheme;
	// /////

	// 연락처 불러오기 메인
	LinearLayout personLayout;
	ArrayList<Person> personArray;
	EditText inputSearch;
	PersonAdapter m_adapter;

	private ListView lv;
	private KakaoLink kakaoLink;
	private KakaoTalkLinkMessageBuilder kakaoTalkLinkMessageBuilder;

	// 슬라이딩 화면 구성-s
	LinearLayout slidingLayout;
	ImageView slidingButton;
	Animation translate_left;
	Animation translate_right;
	boolean open = false;

	// 슬라이딩 왼쪽 화면-s
	LinearLayout myInfo_layout;
	LinearLayout qrcode_layout;
	LinearLayout question_layout;
	LinearLayout faq_layout;
	// View empty_view;
	View empty_view;

	// 그룹 화면
	LinearLayout groupLayout;
	ListView groupList;
	ImageView groupPanel_backButton;
	ImageView groupPanel_groupAddButton;
	ArrayList<Group> groupArray;
	GroupAdapter groupAdapter;
	Animation group_panel_visible_anim;
	Animation group_panel_gone_anim;
	ImageView groupButton;
	ListView personAddList;
	ImageView commitButton;
	ImageView group_add_button;

	boolean addPerson = false;
	boolean commit = false;

	// 사진 수정 관련용
	private static final int PICK_FROM_ALBUM = 1;
	private static final int CROP_FROM_CAMERA = 2;
	private Uri mImageCaptureUri;
	private ImageView profilePciture;
	Bitmap photo = null;

	// 캡쳐용
	boolean captureProfileState = false;
	boolean captureProfile = false;
	String infofilename = null;
	String paintfilename = null;

	// 유투브 용
	String myYoutubeId = "";
	String otherYoutubeId = "";

	// 사진 동기화용
	boolean syncCount = false;
	boolean canState = true;

	static LinearLayout modifyPaintBackgruoud = null;

	public Drawable getTheme(String themeName) {

		int themeIndex = theme.valueOf(themeName).ordinal();
		Drawable profileTheme;

		switch (themeIndex) {
		case 0:
			profileTheme = getResources().getDrawable(
					R.drawable.white_background);
			break;
		case 1:
			profileTheme = getResources().getDrawable(
					R.drawable.circle_background);
			break;
		case 2:
			profileTheme = getResources().getDrawable(
					R.drawable.black_board_background);
			break;
		case 3:
			profileTheme = getResources().getDrawable(
					R.drawable.black_background);
			break;
		case 4:
			profileTheme = getResources().getDrawable(
					R.drawable.brick_background);
			break;
		case 5:
			profileTheme = getResources().getDrawable(
					R.drawable.note_background);
			break;
		case 6:
			profileTheme = getResources().getDrawable(
					R.drawable.note2_background);
			break;
		case 7:
			profileTheme = getResources().getDrawable(
					R.drawable.paint_background);
			break;
		case 8:
			profileTheme = getResources().getDrawable(
					R.drawable.pino_background);
			break;
		case 9:
			profileTheme = getResources().getDrawable(
					R.drawable.rainbow_background);
			break;
		case 10:
			profileTheme = getResources().getDrawable(
					R.drawable.tree_background);
			break;
		default:
			profileTheme = getResources().getDrawable(
					R.drawable.white_background);
			break;
		}
		return profileTheme;
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		Infor infor = new Infor();
		try {
			infor.load(dist);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		if (dist[0] == 0) {
			LinearLayout infor0 = (LinearLayout) View.inflate(
					getApplicationContext(), R.layout.infor0, null);
			setContentView(infor0);
			infor0.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					onBackPressed();
				}
			});
			tutorial0 = true;
		} else {
			init_start();
			setContentView(R.layout.main);
			init_MainActivity();
		}

		try {
			FileWriter fw = new FileWriter(
					"/storage/emulated/0/data/info/exp.txt");
			str_dist = "";
			dist[0] = 1;

			for (int i = 0; i < 4; i++) {
				str_dist += dist[i];
			}
			fw.write(str_dist);
			fw.flush();
			fw.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}

	public void init_start() {
		serverControlMethod = new ServerControlMethod();
		dirPath = "/storage/emulated/0/data/info";

		try {
			File myname = new File("/storage/emulated/0/data/info/myName.txt");
			if (!myname.exists())
				myName = "이름을 입력하세요";

			FileReader reader = new FileReader(myname);
			try {
				int ch;
				myName = "";
				while ((ch = reader.read()) != -1) {
					myName = myName + (char) ch;
				}
				if (myName.equals(""))
					myName = "이름을 입력하세요";
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			myName = "이름을 입력하세요";
			e.printStackTrace();
		}
		if (myName.equals("이름을 입력하세요")) {// TODO

			AlertDialog.Builder alert = new AlertDialog.Builder(
					MainActivity.this);

			alert.setMessage("이름을 입력하세요");
			// Set an EditText view to get user input
			final EditText input = new EditText(MainActivity.this);
			input.setTextSize(12);
			alert.setView(input);

			alert.setPositiveButton("확인",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {

							myName = input.getText().toString();
							try {
								FileWriter fw = new FileWriter(
										"/storage/emulated/0/data/info/myName.txt");

								fw.write(myName);
								fw.flush();
								fw.close();
							} catch (IOException e1) {
								e1.printStackTrace();
							}
							setContentView(R.layout.main);
							init_MainActivity();
						}
					});

			alert.show();

		}

		font = Typeface.createFromAsset(getAssets(), "fonts/ssebong.ttf");

		TelephonyManager systemService = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		myPhoneNumber = systemService.getLine1Number();

		myPhoneNumber = myPhoneNumber.substring(myPhoneNumber.length() - 10,
				myPhoneNumber.length());
		myPhoneNumber = "0" + myPhoneNumber;

		vector_EditTextLayout = new Vector<LinearLayout>();
		vector_EditText = new Vector<EditText[]>();
		vector_TextView = new Vector<TextView[]>();

		detail_profile = new RelativeLayout(getApplicationContext());

		addEditTextLayout = new AddEditTextLayout();
		profile_modify_frameLayout = (FrameLayout) findViewById(R.id.profile_modify_frameLayout);
		//

		boolean profileXml = fileCheck(dirPath, myPhoneNumber + ".xml");
		boolean profileInfo = fileCheck(dirPath, myPhoneNumber + "_info.png");
		boolean qrcode = fileCheck(dirPath, myPhoneNumber + ".png");
		boolean groupXML = fileCheck(dirPath, "groups.xml");

		mythemeName = getThemeName(myPhoneNumber);
		mytheme = theme.valueOf(mythemeName).ordinal();

		createThemeFile(mythemeName);

		if (!profileXml) {
			createXML(dirPath, myPhoneNumber);
			myYoutubeId = "";
		} else {
			ElementReader reader = new ElementReader(myPhoneNumber);
			myYoutubeId = reader.videoURL;
			if (myYoutubeId.equals("null")) {
				myYoutubeId = "";
			}
		}

		if (!profileInfo) {

			Bitmap screenshot = BitmapFactory.decodeResource(getResources(),
					R.drawable.noprofile);
			String infofilename = myPhoneNumber + "_info.png";

			try {
				File f = new File("/storage/emulated/0/data/info", infofilename);
				f.createNewFile();
				OutputStream outStream = new FileOutputStream(f);
				screenshot.compress(Bitmap.CompressFormat.PNG, 100, outStream);
				outStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			boolean check;
			check = serverControlMethod.fileUpload(dirPath, "/" + myPhoneNumber
					+ "_info.png", "screenshot");
		}

		if (!qrcode) {
			createQRCode(dirPath, myPhoneNumber);
		}

		if (!groupXML) {
			groupArray = new ArrayList<Group>();
			createGroupXML(dirPath);
		}
	}

	public boolean fileCheck(String path, String fileName) {

		File file = new File(path + "/" + fileName);

		return file.exists();
	}

	public int DpToPixel(float dp) {
		return (int) (dp * (getApplicationContext().getResources()
				.getDisplayMetrics().densityDpi / 160f));
	}

	public void init_MainActivity() {
		main_layout = (LinearLayout) findViewById(R.id.main_layout);
		// 슬라이딩 화면 구성-s
		slidingLayout = (LinearLayout) findViewById(R.id.slidingLayout);
		slidingButton = (ImageView) findViewById(R.id.slidingButton);
		ImageView buttonPive = (ImageView) findViewById(R.id.button_pive);
		buttonPive.setOnClickListener(new KakaoButtonListener());
		myQRCodeImage = (ImageView) findViewById(R.id.button_qrcode);
		myQRCodeImage.setOnClickListener(myQRCodeImageListener);

		groupButton = (ImageView) findViewById(R.id.group);
		commitButton = (ImageView) findViewById(R.id.commit_button);

		groupArray = new ArrayList<Group>();
		group_panel_gone_anim = AnimationUtils.loadAnimation(this,
				R.anim.group_panel_gone);
		group_panel_visible_anim = AnimationUtils.loadAnimation(this,
				R.anim.group_panel_visible);

		group_panel_gone_anim.setAnimationListener(group_panel_gone);
		group_panel_visible_anim.setAnimationListener(group_panel_visible);

		groupLayout = (LinearLayout) findViewById(R.id.groupLayout);
		groupList = (ListView) findViewById(R.id.group_list);

		ElementReader groupReader = new ElementReader();
		groupArray = groupReader.groupArray;
		groupAdapter = new GroupAdapter(this, groupArray);
		groupList.setAdapter(groupAdapter);
		ImageView slidingPanel_ImageView = (ImageView) findViewById(R.id.sliding_Image);
		File myProfileImage = new File("/storage/emulated/0/data/info/"
				+ myPhoneNumber + ".jpg");
		if (!myProfileImage.exists()) {
			slidingPanel_ImageView.setImageResource(R.drawable.noimage);
		} else {
			Uri myProfileImageUri = Uri.fromFile(myProfileImage);
			Bitmap circleImageBitmap = uriToBitmap(myProfileImageUri);
			slidingPanel_ImageView.setImageBitmap(circleImageBitmap);
		}

		TextView nameTextView = (TextView) findViewById(R.id.sliding_name);
		nameTextView.setText(myName);
		nameTextView.setTypeface(font);
		// ImageView slidingImage = (ImageView)
		// findViewById(R.id.sliding_Image);
		// slidingImage.setImageDrawable(getResources().getDrawable(R.drawable.));

		TextView qrcode = (TextView) findViewById(R.id.textView2);

		TextView notice = (TextView) findViewById(R.id.textView5);
		TextView exit = (TextView) findViewById(R.id.textView6);

		qrcode.setTypeface(font);

		notice.setTypeface(font);
		exit.setTypeface(font);
		translate_left = AnimationUtils.loadAnimation(this,
				R.anim.translate_left);
		translate_right = AnimationUtils.loadAnimation(this,
				R.anim.translate_right);
		translate_right.setAnimationListener(anim_right_listener);
		translate_left.setAnimationListener(anim_left_listener);

		// -슬라이딩 버튼 클릭
		slidingButton.setOnClickListener(slidingbutton_listener);

		// 슬라이딩 화면 내정보
		myInfo_layout = (LinearLayout) findViewById(R.id.myInfo_layout);
		myInfo_layout.setOnClickListener(myInfo_listener);

		// 슬라이딩 화면 1. qr코드
		qrcode_layout = (LinearLayout) findViewById(R.id.qrcode_layout);
		qrcode_layout.setOnClickListener(qrcode_listener);
		// 슬라이딩 화면 2. 설정

		// 슬라이딩 화면 3. 공지사항

		// 슬라이딩 화면 4. 문의하기
		question_layout = (LinearLayout) findViewById(R.id.question_layout);
		question_layout.setOnClickListener(question_listener);
		// 슬라이딩 화면 5. FAQ
		faq_layout = (LinearLayout) findViewById(R.id.faq_layout);
		faq_layout.setOnClickListener(faq_listener);

		empty_view = findViewById(R.id.grayView);
		empty_view.setOnClickListener(empty_listener);

		lv = (ListView) findViewById(R.id.list);
		personArray = new ArrayList<Person>();
		inputSearch = (EditText) findViewById(R.id.inputsearch);

		// 그룹 화면

		groupPanel_backButton = (ImageView) findViewById(R.id.group_panel_backbutton);
		personAddList = (ListView) findViewById(R.id.addPersonList);

		groupPanel_backButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (addPerson) {
					personAddList.setVisibility(View.GONE);
					commitButton.setVisibility(View.GONE);
					groupPanel_groupAddButton.setVisibility(View.VISIBLE);
					addPerson = false;
				} else {
					groupLayout.startAnimation(group_panel_gone_anim);
					group = false;
				}
			}
		});

		groupPanel_groupAddButton = (ImageView) findViewById(R.id.group_add_button);

		groupPanel_groupAddButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				AlertDialog.Builder alert = new AlertDialog.Builder(
						MainActivity.this);

				alert.setMessage("생성할 그룹 이름을 입력하세요");
				// Set an EditText view to get user input
				final EditText input = new EditText(MainActivity.this);
				input.setHint("그룹 이름");
				input.setTextSize(12);
				alert.setView(input);

				alert.setPositiveButton("Ok",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {
								boolean exist = false;
								for (int i = 0; i < groupArray.size(); i++) {
									if (groupArray.get(i).getName()
											.equals(input)) {
										Toast.makeText(MainActivity.this,
												"이미 존재하는 그룹명 입니다.",
												Toast.LENGTH_SHORT).show();
										exist = true;
										break;
									}
								}

								if (!exist) {
									Group group = new Group(input.getText()
											.toString());
									group.addMember(new Person("null", "null"));
									groupArray.add(group);
									createGroupXML(dirPath);
									groupAdapter.notifyDataSetChanged();
									addgroup = true;
								}

							}
						});

				alert.setNegativeButton("Cancel",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {
							}
						});

				alert.show();

			}
		});

		// sms

		// /////////////////////////////////////////////////////////////////////////
		try {
			kakaoLink = KakaoLink.getKakaoLink(getApplicationContext());
		} catch (KakaoParameterException e) {
		}

		kakaoTalkLinkMessageBuilder = kakaoLink
				.createKakaoTalkLinkMessageBuilder();

		Map<String, String> phone_address = ContactUtil.getAddressBook(this);

		@SuppressWarnings("rawtypes")
		Iterator ite = HashSort.sortByValue(phone_address).iterator();
		while (ite.hasNext()) {
			String phoneNumber = ite.next().toString();
			String name = phone_address.get(phoneNumber).toString();

			if (phoneNumber.charAt(3) == '-') {
				if (phoneNumber.charAt(7) == '-') {
					phoneNumber = phoneNumber.substring(0, 3)
							+ phoneNumber.substring(4, 7)
							+ phoneNumber.substring(8);
				} else {
					phoneNumber = phoneNumber.substring(0, 3)
							+ phoneNumber.substring(4, 8)
							+ phoneNumber.substring(9);
				}
			}
			if (personArray.size() == 0)
				personArray.add(new Person(name, phoneNumber));
			else {
				if (!((name.equals(personArray.get(personArray.size() - 1)
						.getName())) && (phoneNumber.equals(personArray.get(
						personArray.size() - 1).getNumber()))))
					personArray.add(new Person(name, phoneNumber));
			}
		}
		LinearLayout myInfoLayout = (LinearLayout) findViewById(R.id.main_myInfo_layout);
		ImageView myProfileImageView = (ImageView) findViewById(R.id.main_my_profile_image);
		TextView myProfileTextView = (TextView) findViewById(R.id.main_my_name_text);

		myProfileTextView.setTypeface(font);
		myInfoLayout.setOnClickListener(myInfo_listener);

		syncPhoto = (ImageView) findViewById(R.id.syncPhoto_button);
		syncPhoto.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (canState) {
					canState = false;
					syncCount = true;
					init_MainActivity();
				}
			}
		});
		if (syncCount) {
			String[] keys = serverControlMethod.getkey();
			ArrayList<String> canSynckeys = new ArrayList<String>();
			for (int i = 0; i < keys.length; i++) {
				if (keys[i].startsWith("profile/0")) {
					for (int j = 0; j < personArray.size(); j++) {
						String fileName = "profile/"
								+ personArray.get(j).getNumber() + ".jpg";
						if (keys[i].equals(fileName)
								&& !personArray.get(j).getNumber()
										.equals(myPhoneNumber)) {
							canSynckeys.add(personArray.get(j).getNumber());
							break;
						}
					}
				}
			}

			boolean check = serverControlMethod.syncPhoto(dirPath, canSynckeys);
			syncCount = false;
		}

		if (fileCheck(dirPath, myPhoneNumber + ".jpg")) {
			File file = new File(dirPath + "/" + myPhoneNumber + ".jpg");
			Uri myProfileImageUri = Uri.fromFile(file);
			Bitmap circleImageBitmap = uriToBitmap(myProfileImageUri);
			myProfileImageView.setImageBitmap(circleImageBitmap);
		} else {
			myProfileImageView.setImageResource(R.drawable.noimage);
		}

		myProfileTextView.setText(myName);
		myProfileTextView.setTextColor(Color.BLACK);

		m_adapter = new PersonAdapter(this, personArray);
		lv.setAdapter(m_adapter);

		groupButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				m_adapter.notifyDataSetChanged();
				// groupAdapter.notifyDataSetChanged();
				group = true;
				groupLayout.startAnimation(group_panel_visible_anim);
			}
		});
		// snsImage.setOnClickListener(sns_send_listener);
		inputSearch.addTextChangedListener(new TextWatcher() {

			@Override
			public void onTextChanged(CharSequence s, int start, int before,
					int count) {
				String text = inputSearch.getText().toString()
						.toLowerCase(Locale.getDefault());
				m_adapter.filter(text);

			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
			}

			@Override
			public void afterTextChanged(Editable s) {

			}
		});
		lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long rowID) {

				if (!group) {

					InputMethodManager imm = (InputMethodManager) view
							.getContext().getSystemService(
									Context.INPUT_METHOD_SERVICE);
					// 감출 때
					imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
					Person selectedPerson = (Person) parent
							.getItemAtPosition(position);

					doSelectFriend(selectedPerson);
				}

			}
		});
	}

	// //////////////////////////////////////////////////////////////////////////
	// /////////////////////////////////////////////////////////////////////
	// ///////////////////////이하 리스너들///////////////////////////////////
	// //////////////////////////////////////////////////////////////////////
	// //////////////////////////////////////////////////////////////////////

	// 슬라이딩 버튼 리스너
	View.OnClickListener slidingbutton_listener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			InputMethodManager imm = (InputMethodManager) v.getContext()
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			// 감출 때
			imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
			if (open) {
				slidingLayout.startAnimation(translate_left);

				open = false;
			} else {
				slidingLayout.setVisibility(View.VISIBLE);
				slidingLayout.startAnimation(translate_right);
				open = true;
			}
		}
	};

	public String getThemeName(String phoneNumber) {

		boolean themefile = fileCheck(dirPath, phoneNumber + "_theme.txt");
		String theme = "";

		if (!themefile)
			theme = "white";
		else {
			File themeFile = new File(dirPath + "/" + phoneNumber
					+ "_theme.txt");
			FileReader reader;
			try {
				reader = new FileReader(themeFile);

				try {
					int ch;
					theme = "";
					while ((ch = reader.read()) != -1) {
						theme = theme + (char) ch;
					}
					if (theme.equals(""))
						theme = "white";
				} catch (IOException e) {
					theme = "white";
					e.printStackTrace();
				}
			} catch (FileNotFoundException e) {
				theme = "white";
				e.printStackTrace();
			}
		}
		return theme;
	}

	// 취소버튼
	@Override
	public void onBackPressed() {
		drawingView.initPaintAble();

		if (tutorial0) {
			tutorial0 = false;
			view_my_profile = false;
			view_other_profile = false;
			view_qrcode = false;
			checkprofile = 0;
			init_start();
			setContentView(R.layout.main);
			init_MainActivity();
			return;
		}
		if (tutorial1) {
			tutorial1 = false;
			view_my_profile = true;
			view_modify_profile = false;
			view_modify_background = false;
			view_my_picture = false;
			checkprofile = 1;
			LinearLayout profile = (LinearLayout) View.inflate(
					getApplicationContext(), R.layout.profile, null);
			setContentView(profile);
			init_profile_layout(myName, myPhoneNumber);

			return;
		}
		if (tutorial2) {
			tutorial2 = false;
			LinearLayout profile_modify = (LinearLayout) View.inflate(
					getApplicationContext(), R.layout.profile_modify, null);
			setContentView(profile_modify);
			init_profile_modify_layout();
			return;
		}
		if (tutorial3) {
			tutorial3 = false;
			view_qrcode = true;
			setContentView(R.layout.qr_image);
			qr_image = (ImageView) findViewById(R.id.qr_image);
			smsImage = (ImageView) findViewById(R.id.snsImage);

			File qrcodeImage = new File("/storage/emulated/0/data/info/"
					+ myPhoneNumber + ".png");
			if (!qrcodeImage.exists()) {
				qr_image.setImageResource(R.drawable.noqrcode);
			} else {
				Uri qrcodeUri = Uri.fromFile(qrcodeImage);
				qr_image.setImageURI(qrcodeUri);
			}
			ImageView backArrow = (ImageView) findViewById(R.id.my_picture_backarrow);
			backArrow.setOnClickListener(backArrow_listener);

			smsImage.setOnClickListener(sms_send_listener);
			return;
		}

		if (open) {
			slidingLayout.startAnimation(translate_left);
			open = false;
			return;
		}
		// 뒤로가기 추가부분
		else if (view_other_profile || view_my_profile || view_qrcode
				|| question) {
			FrameLayout main = (FrameLayout) View.inflate(
					getApplicationContext(), R.layout.main, null);
			setContentView(main);

			init_MainActivity();
			question = false;
			canState = true;
			view_my_profile = false;
			view_other_profile = false;
			view_qrcode = false;
			checkprofile = 0;
			return;

		} else if (view_modify_profile || view_my_picture
				|| view_modify_background) {

			LinearLayout profile = (LinearLayout) View.inflate(
					getApplicationContext(), R.layout.profile, null);
			setContentView(profile);
			view_my_profile = true;
			init_profile_layout(myName, myPhoneNumber);
			view_modify_profile = false;
			view_modify_background = false;
			view_my_picture = false;
			checkprofile = 1;
			return;

		} else if (view_other_picture) {
			LinearLayout profile = (LinearLayout) View.inflate(
					getApplicationContext(), R.layout.profile, null);
			setContentView(profile);
			view_other_profile = true;
			init_profile_layout(otherName, otherPhoneNumber);
			view_other_picture = false;
			checkprofile = 2;
			return;

		} else if (addPerson) {
			personAddList.setVisibility(View.GONE);
			commitButton.setVisibility(View.GONE);
			groupPanel_groupAddButton.setVisibility(View.VISIBLE);
			addPerson = false;

			return;
		}

		else if (group) {
			groupLayout.startAnimation(group_panel_gone_anim);
			group = false;

			return;
		}

		if (openWeb) {
			FrameLayout main = (FrameLayout) View.inflate(
					getApplicationContext(), R.layout.main, null);
			setContentView(main);
			init_MainActivity();
			openWeb = false;
			return;
		}

		super.onBackPressed();
	}

	// 화면 애니메이션 리스너
	AnimationListener group_panel_visible = new AnimationListener() {

		@Override
		public void onAnimationStart(Animation animation) {
			groupLayout.setVisibility(View.VISIBLE);
			groupButton.setVisibility(View.GONE);
			syncPhoto.setVisibility(View.GONE);
			slidingButton.setVisibility(View.GONE);
			groupPanel_groupAddButton.setVisibility(View.VISIBLE);
			groupPanel_backButton.setVisibility(View.VISIBLE);
		}

		@Override
		public void onAnimationRepeat(Animation animation) {

		}

		@Override
		public void onAnimationEnd(Animation animation) {
			// main_layout.setVisibility(View.INVISIBLE);

		}
	};

	AnimationListener group_panel_gone = new AnimationListener() {

		@Override
		public void onAnimationStart(Animation animation) {
			main_layout.setVisibility(View.VISIBLE);
			groupPanel_groupAddButton.setVisibility(View.GONE);
			groupPanel_backButton.setVisibility(View.GONE);
			groupButton.setVisibility(View.VISIBLE);
			slidingButton.setVisibility(View.VISIBLE);
			syncPhoto.setVisibility(View.VISIBLE);
		}

		@Override
		public void onAnimationRepeat(Animation animation) {

		}

		@Override
		public void onAnimationEnd(Animation animation) {
			groupLayout.setVisibility(View.GONE);

		}
	};

	AnimationListener anim_right_listener = new AnimationListener() {

		@Override
		public void onAnimationStart(Animation animation) {
			empty_view.setVisibility(View.VISIBLE);
		}

		@Override
		public void onAnimationRepeat(Animation animation) {

		}

		@Override
		public void onAnimationEnd(Animation animation) {

		}
	};

	AnimationListener anim_left_listener = new AnimationListener() {

		@Override
		public void onAnimationStart(Animation animation) {

		}

		@Override
		public void onAnimationRepeat(Animation animation) {

		}

		@Override
		public void onAnimationEnd(Animation animation) {

			empty_view.setVisibility(View.GONE);
			slidingLayout.setVisibility(View.GONE);

		}
	};

	// myInfo 리스너
	View.OnClickListener myInfo_listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			open = false;
			InputMethodManager imm = (InputMethodManager) v.getContext()
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			// 감출 때
			imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

			LinearLayout profile = (LinearLayout) View.inflate(
					getApplicationContext(), R.layout.profile, null);
			setContentView(profile);
			view_my_profile = true;
			checkprofile = 1;
			init_profile_layout(myName, myPhoneNumber);

			if (dist[1] == 0) {
				LinearLayout infor1 = (LinearLayout) View.inflate(
						getApplicationContext(), R.layout.infor1, null);
				setContentView(infor1);
				infor1.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						onBackPressed();
					}
				});
				tutorial1 = true;
			}
			try {
				FileWriter fw = new FileWriter(
						"/storage/emulated/0/data/info/exp.txt");
				str_dist = "";
				dist[1] = 1;

				for (int i = 0; i < 4; i++) {
					str_dist += dist[i];
				}
				fw.write(str_dist);
				fw.flush();
				fw.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

		}
	};

	public void init_profile_layout(String name, String PhoneNumber) {
		int textColor = getThemeTextColor(PhoneNumber);

		boolean state = false;
		if (PhoneNumber.equals(myPhoneNumber))
			state = true;

		final ImageView backArrow = (ImageView) findViewById(R.id.backArrow1);
		backArrow.setOnClickListener(backArrow_listener);

		final ImageView backgroundModifyButton = (ImageView) findViewById(R.id.backgroundModifyButton);
		backgroundModifyButton
				.setOnClickListener(profile_backgroundModifyButton_listener);

		final ImageView modifyButton = (ImageView) findViewById(R.id.modifyButton);
		modifyButton.setOnClickListener(profile_modifyButton_listener);

		final LinearLayout background = (LinearLayout) findViewById(R.id.profile_background);
		String themeName = getThemeName(PhoneNumber);

		background.setBackground(getTheme(themeName));

		final LinearLayout profile_paintlayout = (LinearLayout) findViewById(R.id.profile_paintlayout);
		File myPaintImage = new File("/storage/emulated/0/data/info/"
				+ PhoneNumber + "_paint.png");
		if (!myPaintImage.exists()) {
			profile_paintlayout.setBackgroundResource(R.drawable.nopaint);
		} else {

			Uri mypaintImageUri = Uri.fromFile(myPaintImage);
			Bitmap paintBitmap;
			try {
				paintBitmap = Images.Media.getBitmap(getContentResolver(),
						mypaintImageUri);
				Drawable drawPaint = new BitmapDrawable(paintBitmap);
				profile_paintlayout.setBackground(drawPaint);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (state) {
			backgroundModifyButton.setVisibility(View.VISIBLE);
			modifyButton.setVisibility(View.VISIBLE);
		} else {
			backgroundModifyButton.setVisibility(View.GONE);
			modifyButton.setVisibility(View.GONE);
		}
		// /////////////////////
		TextView myNameTextView = (TextView) findViewById(R.id.myName);
		myNameTextView.setText(name);
		myNameTextView.setTypeface(font);

		TextView myPhoneNumberTextView = (TextView) findViewById(R.id.myPhoneNumber);
		myPhoneNumberTextView.setText(PhoneNumber);
		myPhoneNumberTextView.setTypeface(font);

		TextView textView_name = (TextView) findViewById(R.id.textView_name);
		TextView textView_phoneNumber = (TextView) findViewById(R.id.textView_phonenumber);

		textView_name.setTypeface(font);
		textView_name.setTextColor(textColor);
		textView_phoneNumber.setTextColor(textColor);
		textView_phoneNumber.setTypeface(font);

		myNameTextView.setTextColor(textColor);
		myNameTextView.setTextSize(DpToPixel((float) 7.5));
		myPhoneNumberTextView.setTextColor(textColor);
		myPhoneNumberTextView.setTextSize(DpToPixel((float) 7.5));
		// ////////////////////

		ImageView profile_ImageView = (ImageView) findViewById(R.id.profile_Image);
		File myProfileImage = new File("/storage/emulated/0/data/info/"
				+ PhoneNumber + ".jpg");

		if (!myProfileImage.exists()) {
			profile_ImageView.setImageResource(R.drawable.noimage);
		} else {

			Uri myProfileImageUri = Uri.fromFile(myProfileImage);
			Bitmap circleImageBitmap = uriToBitmap(myProfileImageUri);
			profile_ImageView.setImageBitmap(circleImageBitmap);

		}

		profile_ImageView.setOnClickListener(new PersonLayoutImageListener(
				PhoneNumber));

		profile_frame = (FrameLayout) findViewById(R.id.profile_frameLayout);
		RelativeLayout detail_profile = new RelativeLayout(
				getApplicationContext());

		detail_profile = settingProfile(detail_profile, PhoneNumber);

		profile_frame.addView(detail_profile);

		if (!state) {
			final ImageView youtubeButton = (ImageView) findViewById(R.id.youtubebutton);
			youtubeButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if (!otherYoutubeId.equals("")) {
						Intent intent = new Intent(MainActivity.this,
								ViewYoutubeplayer.class);
						intent.putExtra("YOUTUBEID", otherYoutubeId);
						startActivity(intent);
					} else {
						Toast.makeText(getApplicationContext(),
								"영상 주소가 잘 못 되었습니다.", Toast.LENGTH_SHORT).show();
					}

				}
			});
		} else {
			final ImageView youtubeButton = (ImageView) findViewById(R.id.youtubebutton);
			youtubeButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					if (!myYoutubeId.equals("")) {
						Intent intent = new Intent(MainActivity.this,
								ViewYoutubeplayer.class);
						intent.putExtra("YOUTUBEID", myYoutubeId);
						startActivity(intent);
					} else {
						Toast.makeText(getApplicationContext(),
								"영상 주소가 잘 못 되었습니다.", Toast.LENGTH_SHORT).show();
					}
				}
			});
		}

		if (captureProfile && state) {
			captureProfile = false;
			new testScreen().execute();
			captureProfileState = true;
		}
	}

	public int getThemeTextColor(String phoneNumber) {// TODO
		int textColor = Color.rgb(0, 0, 0);
		String themeName;

		themeName = getThemeName(phoneNumber);
		if (themeName.equals("white")) {
			textColor = Color.rgb(0, 0, 0);
		} else if (themeName.equals("circle")) {
			textColor = Color.rgb(0, 0, 0);
		} else if (themeName.equals("blackboard")) {
			textColor = Color.rgb(255, 255, 255);
		} else if (themeName.equals("black")) {
			textColor = Color.rgb(255, 255, 255);

		} else if (themeName.equals("brick")) {
			textColor = Color.rgb(0, 0, 0);
		} else if (themeName.equals("note")) {
			textColor = Color.rgb(0, 0, 0);
		} else if (themeName.equals("note2")) {
			textColor = Color.rgb(255, 255, 255);
		} else if (themeName.equals("paint")) {
			textColor = Color.rgb(0, 0, 0);
		} else if (themeName.equals("pino")) {
			textColor = Color.rgb(0, 0, 0);
		} else if (themeName.equals("rainbow")) {
			textColor = Color.rgb(255, 255, 255);
		} else if (themeName.equals("tree")) {
			textColor = Color.rgb(0, 0, 0);
		}
		return textColor;
	}

	public int getHintTextColor(String phoneNumber) {// TODO
		int HintColor = Color.rgb(0, 0, 0);
		String themeName;

		themeName = getThemeName(phoneNumber);
		if (themeName.equals("white")) {
			HintColor = Color.GRAY;
		} else if (themeName.equals("circle")) {
			HintColor = Color.GRAY;
		} else if (themeName.equals("blackboard")) {
			HintColor = Color.GRAY;
		} else if (themeName.equals("black")) {
			HintColor = Color.GRAY;

		} else if (themeName.equals("brick")) {
			HintColor = Color.GRAY;
		} else if (themeName.equals("note")) {
			HintColor = Color.GRAY;
		} else if (themeName.equals("note2")) {
			HintColor = Color.GRAY;
		} else if (themeName.equals("paint")) {
			HintColor = Color.GRAY;
		} else if (themeName.equals("pino")) {
			HintColor = Color.GRAY;
		} else if (themeName.equals("rainbow")) {
			HintColor = Color.GRAY;
		} else if (themeName.equals("tree")) {
			HintColor = Color.GRAY;
		}
		return HintColor;

	}

	public RelativeLayout settingProfile(RelativeLayout detail_profile,
			String PhoneNumber) {
		vector_EditText.clear();
		vector_EditTextLayout.clear();
		vector_TextView.clear();
		int textColor = Color.rgb(0, 0, 0);

		// Typeface font = Typeface.createFromAsset(getAssets(),
		// "fonts/human.ttf");

		try {
			ElementReader elementReader = new ElementReader(PhoneNumber);
			otherYoutubeId = elementReader.videoURL;
			if (otherYoutubeId.equals("null"))
				otherYoutubeId = "";

			textColor = getThemeTextColor(PhoneNumber);

			for (int i = 0; i < elementReader.profileItems_vector.size(); i++) {

				LinearLayout temp = new LinearLayout(getApplicationContext());
				LayoutParams params = new LayoutParams(
						android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
						android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
				params.setMargins(elementReader.profileItems_vector.get(i)
						.getX(), elementReader.profileItems_vector.get(i)
						.getY(), 0, 0);
				temp.setLayoutParams(params);
				temp.setPadding(DpToPixel(20), 0, 0, 0);

				TextView[] textView_temp = new TextView[2];

				for (int j = 0; j < textView_temp.length; j++) {

					textView_temp[j] = new TextView(getApplicationContext());

					textView_temp[j].setTextColor(textColor);

					textView_temp[j].setTypeface(font);
					textView_temp[j].setTextSize(DpToPixel(8));

					textView_temp[j].setPadding(DpToPixel(3), DpToPixel(3),
							DpToPixel(3), DpToPixel(3));
				}

				textView_temp[0].setText(elementReader.profileItems_vector.get(
						i).getName());
				textView_temp[1].setText(elementReader.profileItems_vector.get(
						i).getAttribute());

				temp.addView(textView_temp[0]);
				temp.addView(textView_temp[1]);

				vector_EditTextLayout.add(temp);
				vector_TextView.add(textView_temp);

				detail_profile.addView(temp);

			}
		} catch (Exception e) {

		}
		return detail_profile;

	}

	public void init_profile_modify_layout() {// TODO
		view_modify_profile = true;
		final ImageView profile_modify_cancelButton = (ImageView) findViewById(R.id.profile_modify_cancelButton);
		final ImageView profile_modify_saveButton = (ImageView) findViewById(R.id.profile_modify_saveButton);

		ImageView circle;
		LinearLayout temp;

		int textColor = getThemeTextColor(myPhoneNumber);
		int hintColor = getHintTextColor(myPhoneNumber);

		LinearLayout myNameLinearLayout = (LinearLayout) findViewById(R.id.profile_modify_nameLayout);
		EditText myNameEditText = new EditText(getApplicationContext());

		FrameLayout myFrameLayout = (FrameLayout) findViewById(R.id.profile_modify_alllayout);
		myFrameLayout.setOnTouchListener(new OnTouchListener() {

			@Override
			public boolean onTouch(View v, MotionEvent arg1) {
				InputMethodManager imm = (InputMethodManager) v.getContext()
						.getSystemService(Context.INPUT_METHOD_SERVICE);

				imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
				return true;
			}

		});

		ImageView btnModifyYoutubeId = (ImageView) findViewById(R.id.modify_youtubebutton);
		btnModifyYoutubeId.setOnClickListener(inputYoutubeId);

		LinearLayout background = (LinearLayout) findViewById(R.id.profile_modify_background);
		String themeName = getThemeName(myPhoneNumber);
		background.setBackground(getTheme(themeName));

		modifyPaintBackgruoud = (LinearLayout) findViewById(R.id.profile_modify_paintlayout);
		File myPaintImage = new File("/storage/emulated/0/data/info/"
				+ myPhoneNumber + "_paint.png");
		if (!myPaintImage.exists()) {
			modifyPaintBackgruoud.setBackgroundResource(R.drawable.nopaint);
		} else {

			Uri mypaintImageUri = Uri.fromFile(myPaintImage);
			Bitmap paintBitmap;
			try {
				paintBitmap = Images.Media.getBitmap(getContentResolver(),
						mypaintImageUri);

				Drawable drawPaint = new BitmapDrawable(paintBitmap);
				modifyPaintBackgruoud.setBackground(drawPaint);
			} catch (Exception e) {

				e.printStackTrace();
			}
		}

		ImageView slidingPanel_ImageView = (ImageView) findViewById(R.id.profile_modify_profilePciture);
		File myProfileImage = new File("/storage/emulated/0/data/info/"
				+ myPhoneNumber + ".jpg");
		if (!myProfileImage.exists()) {
			slidingPanel_ImageView.setImageResource(R.drawable.noimage);
		} else {
			Uri myProfileImageUri = Uri.fromFile(myProfileImage);
			Bitmap circleImageBitmap = uriToBitmap(myProfileImageUri);
			slidingPanel_ImageView.setImageBitmap(circleImageBitmap);
		}
		if (myName.startsWith("이름을 입력하세요")) {
			myNameEditText.setHint(myName);
			myNameEditText.setText("");

		} else {
			myNameEditText.setText(myName);
		}
		myNameEditText.setHintTextColor(hintColor);

		myNameLinearLayout.removeViewAt(0);
		myNameLinearLayout.addView(myNameEditText, 0);

		TextView textView_name = (TextView) findViewById(R.id.textView_name);
		TextView textView_phoneNumber = (TextView) findViewById(R.id.textView_phonenumber);

		textView_name.setTextColor(textColor);
		textView_phoneNumber.setTextColor(textColor);

		textView_name.setTypeface(font);
		textView_phoneNumber.setTypeface(font);

		TextView myPhoneNumberTextView = (TextView) findViewById(R.id.profile_modify_myPhoneNumber);
		myPhoneNumberTextView.setText(myPhoneNumber);

		myNameEditText.setTextSize(DpToPixel((float) 7.5));
		myNameEditText.setTextColor(Color.GRAY);
		myPhoneNumberTextView.setTextColor(textColor);
		myPhoneNumberTextView.setTextSize(DpToPixel((float) 7.5));

		myNameEditText.setTypeface(font);
		myPhoneNumberTextView.setTypeface(font);

		Profile_modify_saveButton_listener profile_modify_saveButton_listener = new Profile_modify_saveButton_listener(
				myNameEditText);

		profile_modify_cancelButton
				.setOnClickListener(MainActivity.this.profile_modify_cancelButton_listener);
		profile_modify_saveButton
				.setOnClickListener(profile_modify_saveButton_listener);

		profile_modify_frame = (FrameLayout) findViewById(R.id.profile_modify_frameLayout);
		detail_modify_profile = new RelativeLayout(getApplicationContext());
		profile_modify_frame.addView(detail_modify_profile);

		vector_EditText.clear();
		vector_EditTextLayout.clear();
		vector_TextView.clear();
		try {
			ElementReader elementReader = new ElementReader(myPhoneNumber);

			for (int i = 0; i < elementReader.profileItems_vector.size(); i++) {

				temp = new LinearLayout(getApplicationContext());
				LayoutParams params = new LayoutParams(
						android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
						android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
				params.setMargins(elementReader.profileItems_vector.get(i)
						.getX(), elementReader.profileItems_vector.get(i)
						.getY(), 0, 0);
				temp.setLayoutParams(params);

				circle = new ImageView(getApplicationContext());
				circle.setBackground(getResources().getDrawable(
						R.drawable.circle));

				EditText[] editText_temp = new EditText[2];

				for (int j = 0; j < editText_temp.length; j++) {

					editText_temp[j] = new EditText(getApplicationContext());

					editText_temp[j].setTextColor(Color.GRAY);

					editText_temp[j].setTextSize(DpToPixel(7));

					editText_temp[j].setPadding(DpToPixel(3), DpToPixel(3),
							DpToPixel(3), DpToPixel(3));
				}

				editText_temp[0].setText(elementReader.profileItems_vector.get(
						i).getName());
				editText_temp[1].setText(elementReader.profileItems_vector.get(
						i).getAttribute());

				temp.addView(circle);
				temp.addView(editText_temp[0]);
				temp.addView(editText_temp[1]);

				vector_EditTextLayout.add(temp);
				vector_EditTextLayout.lastElement().setOnTouchListener(
						new LayoutTouchListener(vector_EditTextLayout
								.lastElement()));

				vector_EditText.add(editText_temp);

				detail_modify_profile.addView(temp);

			}
		} catch (Exception e) {
		}
		profile_modify_plusImage = (ImageView) findViewById(R.id.profile_modify_plusImage);
		profile_modify_plusImage
				.setOnClickListener(profile_modify_plusImageListener);

		profilePciture = (ImageView) findViewById(R.id.profile_modify_profilePciture);
		profilePciture.setOnClickListener(profilePciture_listener);

		final ImageView startPaint = (ImageView) findViewById(R.id.profile_modify_startPaint);
		final ImageView drawPen = (ImageView) findViewById(R.id.profile_modify_drawPen);
		final ImageView removePaint = (ImageView) findViewById(R.id.profile_modify_removePaint);
		final ImageView changeColor = (ImageView) findViewById(R.id.profile_modify_ChangePenColor);
		final ImageView changeSize = (ImageView) findViewById(R.id.profile_modify_ChangePenSize);
		final ImageView initCanvas = (ImageView) findViewById(R.id.profile_modify_initCanvas);
		final LinearLayout profile_modify_menulayout = (LinearLayout) findViewById(R.id.profile_modify_menulayout);

		startPaint.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (drawingView.isAble()) {
					drawingView.setPaintAble();
					if (drawingView.isRemove()) {
						drawingView.setRemove();
					}
					if (drawingView.isinitCanvas()) {
						drawingView.setInitCanvas();
					}
					profile_modify_menulayout.setBackgroundColor(Color
							.parseColor("#00000000"));
					drawPen.setVisibility(View.INVISIBLE);
					removePaint.setVisibility(View.INVISIBLE);
					changeColor.setVisibility(View.INVISIBLE);
					changeSize.setVisibility(View.INVISIBLE);
					initCanvas.setVisibility(View.INVISIBLE);

				} else {
					drawingView.setPaintAble();
					drawPen.setVisibility(View.VISIBLE);
					removePaint.setVisibility(View.VISIBLE);
					changeColor.setVisibility(View.VISIBLE);
					changeSize.setVisibility(View.VISIBLE);
					initCanvas.setVisibility(View.VISIBLE);
					profile_modify_menulayout.setBackgroundColor(Color.WHITE);

				}

			}

		});
		drawPen.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (drawingView.isRemove()) {
					drawingView.setRemove();
				}
			}

		});
		removePaint.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!drawingView.isRemove()) {
					drawingView.setRemove();
				}
			}

		});
		changeColor.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				final CharSequence[] penColor = { "Black", "White", "Red",
						"Blue", "Green", "Yellow" };
				AlertDialog.Builder alert = new AlertDialog.Builder(
						MainActivity.this);

				alert.setTitle("펜의 색깔을 정해주세요.");
				alert.setItems(penColor, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int penColor) {
						drawingView.setPenColor(penColor);
					}
				});
				alert.show();
			}
		});
		changeSize.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				final CharSequence[] penColor = { "3", "4", "5", "6", "7", "8",
						"9", "10", "11", "12", "13", "14", "15" };
				AlertDialog.Builder alert = new AlertDialog.Builder(
						MainActivity.this);

				alert.setTitle("펜심의 두께를 정해주세요.");
				alert.setItems(penColor, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int penSize) {
						drawingView.setPenSize(penSize);
					}
				});
				alert.show();
			}
		});

		initCanvas.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				drawingView.setInitCanvas();
			}
		});
	}

	View.OnClickListener profile_modify_cancelButton_listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			InputMethodManager imm = (InputMethodManager) v.getContext()
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			// 감출 때
			imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
			view_modify_profile = false;
			view_modify_background = false;
			view_my_profile = true;
			drawingView.initCanvas();

			mythemeName = getThemeName(myPhoneNumber);
			mytheme = theme.valueOf(mythemeName).ordinal();

			LinearLayout profile = (LinearLayout) View.inflate(
					getApplicationContext(), R.layout.profile, null);
			setContentView(profile);
			init_profile_layout(myName, myPhoneNumber);

		}
	};

	public void createGroupXML(String path) {
		GroupXMLWriter.Open(path);

		for (int i = 0; i < groupArray.size(); i++) {

			Vector<Person> groupMembers = groupArray.get(i).getMember();

			for (int j = 0; j < groupMembers.size(); j++) {
				GroupXMLWriter.memberWriter(groupArray.get(i).getName(),
						groupMembers.get(j).getName(), groupMembers.get(j)
								.getNumber(), path);
			}
		}

		GroupXMLWriter.close(path);
	}

	public void createXML(String path, String fileName) {

		EditText[] editTextArray = new EditText[2];
		editTextArray[0] = new EditText(getApplicationContext());
		editTextArray[1] = new EditText(getApplicationContext());

		XMLWriter.Open(path, fileName, myYoutubeId);
		for (int i = 0; i < vector_EditTextLayout.size(); i++) {
			editTextArray = vector_EditText.get(i);
			String name = editTextArray[0].getText().toString();
			String attribute = editTextArray[1].getText().toString();

			XMLWriter.profileItemObjWriter(name, attribute,
					vector_EditTextLayout.get(i).getLeft(),
					vector_EditTextLayout.get(i).getTop(), path, fileName);

		}
		XMLWriter.close(path, fileName);
	}

	public class Profile_modify_saveButton_listener implements OnClickListener {

		EditText myNameEditText;

		Profile_modify_saveButton_listener() {

		}

		Profile_modify_saveButton_listener(EditText myNameEditText) {
			this.myNameEditText = myNameEditText;
		}

		@Override
		public void onClick(View v) {
			if (v.getId() == R.id.profile_modify_saveButton) {
				view_modify_profile = false;
				view_modify_background = false;
				view_my_profile = true;
				captureProfile = true;

				InputMethodManager imm = (InputMethodManager) v.getContext()
						.getSystemService(Context.INPUT_METHOD_SERVICE);
				// 감출 때
				imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

				myName = myNameEditText.getText().toString();

				try {
					LinearLayout paintLayout = (LinearLayout) findViewById(R.id.profile_modify_paintlayout);
					paintLayout.setDrawingCacheEnabled(true);

					Bitmap screenshot = paintLayout.getDrawingCache();
					paintfilename = myPhoneNumber + "_paint.png";

					try {
						File f = new File("/storage/emulated/0/data/info",
								paintfilename);
						if (f.exists()) {
							f.delete();
						}
						f.createNewFile();
						OutputStream outStream = new FileOutputStream(f);
						screenshot.compress(Bitmap.CompressFormat.PNG, 100,
								outStream);
						outStream.close();
					} catch (Exception e) {
					}
					paintLayout.setDrawingCacheEnabled(false);

					drawingView.initCanvas();
					boolean check = serverControlMethod.fileUpload(dirPath, "/"
							+ paintfilename, "paint");
				} catch (Exception e) {
				}

				try {
					FileWriter fw = new FileWriter(
							"/storage/emulated/0/data/info/myName.txt");

					fw.write(myName);
					fw.flush();
					fw.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

				createXML(dirPath, myPhoneNumber);

				// 서버저장

				File file = new File(dirPath);
				String filename = "/" + myPhoneNumber + ".xml";
				// 일치하는 폴더가 없으면 생성
				if (!file.exists()) {
					file.mkdirs();
				}

				try {
					boolean result = serverControlMethod.fileUpload(dirPath,
							filename, "xml");
					if (result) {
					} else {
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				// /////////////////////////////////////////////////////////qr코드
				// 생성후
				// 저장
				String qr_input = "http://s3-ap-northeast-1.amazonaws.com/piveapp/detail_profile_xml/"
						+ myPhoneNumber + ".xml";

				WindowManager manager = (WindowManager) getSystemService(WINDOW_SERVICE);
				Display display = manager.getDefaultDisplay();

				Point point = new Point();
				display.getSize(point);
				int width = point.x;
				int height = point.y;
				int smallerDimension = width < height ? width : height;
				smallerDimension = smallerDimension * 3 / 4;

				createQRCode(dirPath, myPhoneNumber);

				String imageFilename = "/" + myPhoneNumber + ".jpg";

				if (photo != null) {
					File photoFile = new File(dirPath + imageFilename);
					BufferedOutputStream out = null;

					try {
						photoFile.createNewFile();
						out = new BufferedOutputStream(new FileOutputStream(
								photoFile));
						photo.compress(CompressFormat.JPEG, 100, out);
						out.flush();
						out.close();
					} catch (Exception e) {
						e.printStackTrace();
					}

					boolean check = serverControlMethod.fileUpload(dirPath,
							imageFilename, "profile");
					photo = null;
				}

				LinearLayout profile = (LinearLayout) View.inflate(
						getApplicationContext(), R.layout.profile, null);
				setContentView(profile);
				init_profile_layout(myName, myPhoneNumber);
			} else if (v.getId() == R.id.background_modify_saveButton) {

				captureProfile = true;
				createThemeFile(mythemeName);
				LinearLayout profile = (LinearLayout) View.inflate(
						getApplicationContext(), R.layout.profile, null);
				setContentView(profile);
				init_profile_layout(myName, myPhoneNumber);

			}

		}
	}

	public void createThemeFile(String themeName) {

		try {
			FileWriter fw = new FileWriter("/storage/emulated/0/data/info/"
					+ myPhoneNumber + "_theme.txt");

			fw.write(themeName);
			fw.flush();
			fw.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

	}

	public void createQRCode(String path, String fileName) {
		String qr_input = "http://s3-ap-northeast-1.amazonaws.com/piveapp/screenshot/"
				+ myPhoneNumber + "_info.png";

		WindowManager manager = (WindowManager) getSystemService(WINDOW_SERVICE);
		Display display = manager.getDefaultDisplay();

		Point point = new Point();
		display.getSize(point);
		int width = point.x;
		int height = point.y;
		int smallerDimension = width < height ? width : height;
		smallerDimension = smallerDimension * 3 / 4;

		QRCodeEncoder qrCodeEncoder = new QRCodeEncoder(qr_input, null,
				Contents.Type.TEXT, BarcodeFormat.QR_CODE.toString(),
				smallerDimension);
		try {
			Bitmap bitmap = qrCodeEncoder.encodeAsBitmap();
			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream(path + "/" + fileName + ".png");
				if (fos != null) {
					bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
				}
			} catch (Exception e) {
				Log.e("bitmapsave fail", e.getMessage());
			}

		} catch (WriterException e) {
			e.printStackTrace();
		}
	}

	class BackgroundScrollImageListener implements View.OnClickListener {
		ImageView[] check;
		LinearLayout background;

		BackgroundScrollImageListener() {

		}

		BackgroundScrollImageListener(ImageView[] check, LinearLayout background) {
			this.check = check;
			this.background = background;
		}

		@Override
		public void onClick(View v) {
			switch (v.getId()) {
			case R.id.backgroundScrollImage0:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[0].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.white_background));
				mythemeName = "white";
				mytheme = 0;
				break;
			case R.id.backgroundScrollImage1:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[1].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.circle_background));
				mythemeName = "circle";
				mytheme = 1;
				break;
			case R.id.backgroundScrollImage2:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[2].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.black_board_background));
				mythemeName = "blackboard";
				mytheme = 2;
				break;
			case R.id.backgroundScrollImage3:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[3].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.black_background));
				mythemeName = "black";
				mytheme = 3;
				break;
			case R.id.backgroundScrollImage4:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[4].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.brick_background));
				mythemeName = "brick";
				mytheme = 4;
				break;
			case R.id.backgroundScrollImage5:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[5].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.note_background));
				mythemeName = "note";
				mytheme = 5;
				break;
			case R.id.backgroundScrollImage6:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[6].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.note2_background));
				mythemeName = "note2";
				mytheme = 6;
				break;
			case R.id.backgroundScrollImage7:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[7].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.paint_background));
				mythemeName = "paint";
				mytheme = 7;
				break;
			case R.id.backgroundScrollImage8:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[8].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.pino_background));
				mythemeName = "pino";
				mytheme = 8;
				break;
			case R.id.backgroundScrollImage9:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[9].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.rainbow_background));
				mythemeName = "rainbow";
				mytheme = 9;
				break;
			case R.id.backgroundScrollImage10:
				for (int i = 0; i < check.length; i++)
					check[i].setVisibility(View.GONE);
				check[10].setVisibility(View.VISIBLE);
				background.setBackground(getResources().getDrawable(
						R.drawable.tree_background));
				mythemeName = "tree";
				mytheme = 10;
				break;
			}
		}

	}

	View.OnClickListener profile_backgroundModifyButton_listener = new View.OnClickListener() {
		ImageView[] check = new ImageView[11];

		@Override
		public void onClick(View v) {
			if (!captureProfileState) {
				view_my_profile = false;
				view_modify_background = true;
				LinearLayout profile_background_modify = (LinearLayout) View
						.inflate(getApplicationContext(),
								R.layout.background_modify, null);

				setContentView(profile_background_modify);

				final ImageView cancelButton = (ImageView) findViewById(R.id.background_modify_cancelButton);
				final ImageView saveButton = (ImageView) findViewById(R.id.background_modify_saveButton);
				final LinearLayout background = (LinearLayout) findViewById(R.id.background_modify_background);

				final ImageView backgroundScrollImage0 = (ImageView) findViewById(R.id.backgroundScrollImage0);
				final ImageView backgroundScrollImage1 = (ImageView) findViewById(R.id.backgroundScrollImage1);
				final ImageView backgroundScrollImage2 = (ImageView) findViewById(R.id.backgroundScrollImage2);
				final ImageView backgroundScrollImage3 = (ImageView) findViewById(R.id.backgroundScrollImage3);
				final ImageView backgroundScrollImage4 = (ImageView) findViewById(R.id.backgroundScrollImage4);
				final ImageView backgroundScrollImage5 = (ImageView) findViewById(R.id.backgroundScrollImage5);
				final ImageView backgroundScrollImage6 = (ImageView) findViewById(R.id.backgroundScrollImage6);
				final ImageView backgroundScrollImage7 = (ImageView) findViewById(R.id.backgroundScrollImage7);
				final ImageView backgroundScrollImage8 = (ImageView) findViewById(R.id.backgroundScrollImage8);
				final ImageView backgroundScrollImage9 = (ImageView) findViewById(R.id.backgroundScrollImage9);
				final ImageView backgroundScrollImage10 = (ImageView) findViewById(R.id.backgroundScrollImage10);

				check[0] = (ImageView) findViewById(R.id.check0);
				check[1] = (ImageView) findViewById(R.id.check1);
				check[2] = (ImageView) findViewById(R.id.check2);
				check[3] = (ImageView) findViewById(R.id.check3);
				check[4] = (ImageView) findViewById(R.id.check4);
				check[5] = (ImageView) findViewById(R.id.check5);
				check[6] = (ImageView) findViewById(R.id.check6);
				check[7] = (ImageView) findViewById(R.id.check7);
				check[8] = (ImageView) findViewById(R.id.check8);
				check[9] = (ImageView) findViewById(R.id.check9);
				check[10] = (ImageView) findViewById(R.id.check10);
				check[mytheme].setVisibility(View.VISIBLE);
				switch (mytheme) {
				case 0:
					background.setBackground(getResources().getDrawable(
							R.drawable.white_background));
					break;
				case 1:
					background.setBackground(getResources().getDrawable(
							R.drawable.circle_background));
					break;
				case 2:
					background.setBackground(getResources().getDrawable(
							R.drawable.black_board_background));
					break;
				case 3:
					background.setBackground(getResources().getDrawable(
							R.drawable.black_background));
					break;
				case 4:
					background.setBackground(getResources().getDrawable(
							R.drawable.brick_background));
					break;
				case 5:
					background.setBackground(getResources().getDrawable(
							R.drawable.note_background));
					break;
				case 6:
					background.setBackground(getResources().getDrawable(
							R.drawable.note2_background));
					break;
				case 7:
					background.setBackground(getResources().getDrawable(
							R.drawable.paint_background));
					break;
				case 8:
					background.setBackground(getResources().getDrawable(
							R.drawable.pino_background));
					break;
				case 9:
					background.setBackground(getResources().getDrawable(
							R.drawable.rainbow_background));
					break;
				case 10:
					background.setBackground(getResources().getDrawable(
							R.drawable.tree_background));
					break;
				}

				BackgroundScrollImageListener backgroundScrollImageListener = new BackgroundScrollImageListener(
						check, background);

				backgroundScrollImage0
						.setOnClickListener(backgroundScrollImageListener);
				backgroundScrollImage1
						.setOnClickListener(backgroundScrollImageListener);
				backgroundScrollImage2
						.setOnClickListener(backgroundScrollImageListener);
				backgroundScrollImage3
						.setOnClickListener(backgroundScrollImageListener);
				backgroundScrollImage4
						.setOnClickListener(backgroundScrollImageListener);

				backgroundScrollImage5
						.setOnClickListener(backgroundScrollImageListener);
				backgroundScrollImage6
						.setOnClickListener(backgroundScrollImageListener);
				backgroundScrollImage7
						.setOnClickListener(backgroundScrollImageListener);
				backgroundScrollImage8
						.setOnClickListener(backgroundScrollImageListener);
				backgroundScrollImage9
						.setOnClickListener(backgroundScrollImageListener);
				backgroundScrollImage10
						.setOnClickListener(backgroundScrollImageListener);

				cancelButton
						.setOnClickListener(profile_modify_cancelButton_listener);

				Profile_modify_saveButton_listener profile_modify_saveButton_listener = new Profile_modify_saveButton_listener();

				saveButton
						.setOnClickListener(profile_modify_saveButton_listener);

			}
		}
	};

	View.OnClickListener profile_modifyButton_listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			if (!captureProfileState) {
				view_my_profile = false;

				LinearLayout profile_modify = (LinearLayout) View.inflate(
						getApplicationContext(), R.layout.profile_modify, null);
				setContentView(profile_modify);
				init_profile_modify_layout();

				if (dist[2] == 0) {
					LinearLayout infor2 = (LinearLayout) View.inflate(
							getApplicationContext(), R.layout.infor2, null);
					setContentView(infor2);
					infor2.setOnClickListener(new OnClickListener() {

						@Override
						public void onClick(View v) {
							onBackPressed();
						}
					});
					tutorial2 = true;
				}
				try {
					FileWriter fw = new FileWriter(
							"/storage/emulated/0/data/info/exp.txt");
					str_dist = "";
					dist[2] = 1;

					for (int i = 0; i < 4; i++) {
						str_dist += dist[i];
					}
					fw.write(str_dist);
					fw.flush();
					fw.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}
		}

	};

	// 뒤로가기 버튼
	View.OnClickListener backArrow_listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			if (view_my_picture || view_other_picture) {
				if (view_my_picture) {
					LinearLayout profile = (LinearLayout) View.inflate(
							getApplicationContext(), R.layout.profile, null);
					setContentView(profile);
					init_profile_layout(myName, myPhoneNumber);
					view_my_picture = false;
					view_my_profile = true;
					checkprofile = 1;
				} else {
					LinearLayout profile = (LinearLayout) View.inflate(
							getApplicationContext(), R.layout.profile, null);
					setContentView(profile);
					init_profile_layout(otherName, otherPhoneNumber);
					view_other_picture = false;
					view_other_profile = true;
					checkprofile = 2;
				}
			} else {
				if (!captureProfileState) {
					view_my_profile = false;
					view_other_profile = false;
					canState = true;
					FrameLayout main = (FrameLayout) View.inflate(
							getApplicationContext(), R.layout.main, null);
					setContentView(main);
					checkprofile = 0;
					init_MainActivity();
				}
			}
		}
	};

	// qr코드 리스너-s
	View.OnClickListener qrcode_listener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			IntentIntegrator.initiateScan(MainActivity.this);
			onQr = true;
		}
	};

	// setting코드 리스너-s View.OnClickListener setting_listener = new
	View.OnClickListener setting_listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
		}
	};

	// notice코드 리스너-s
	View.OnClickListener notice_listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {

		}
	};

	// question코드 리스너-s
	View.OnClickListener question_listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			setContentView(R.layout.question);
			question = true;
			open = false;
			ImageView backbutton = (ImageView) findViewById(R.id.question_view);
			backbutton.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					onBackPressed();

				}
			});
		}
	};

	// faq코드 리스너-s
	View.OnClickListener faq_listener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {

			AlertDialog.Builder alert = new AlertDialog.Builder(
					MainActivity.this);

			alert.setMessage("종료하시겠습니까?");

			alert.setPositiveButton("네", new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int whichButton) {
					finish();

				}
			});

			alert.setNegativeButton("아니요",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {
						}
					});

			alert.show();

		}

	};

	View.OnClickListener empty_listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			slidingLayout.startAnimation(translate_left);
			open = false;
		}
	};

	// ////////////////////�댋諛� ///////////////////
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	// ////////////////////////////////////////////////

	// ////////////////////////////////////////
	@Override
	protected void onResume() {
		super.onResume();

	}

	private void redirectLoginActivity() {
		Intent intent = new Intent(this, LoginActivity.class);
		startActivity(intent);
		finish();
	}

	// ////////////////////////////////////////

	public void doSelectFriend(Person p) {

		String dirpath = "/storage/emulated/0/data/info";
		String filename = "/" + p.getNumber() + ".xml";
		String imagename = "/" + p.getNumber() + ".jpg";
		String themename = "/" + p.getNumber() + "_theme.txt";
		String paintname = "/" + p.getNumber() + "_paint.png";

		boolean check;

		check = serverControlMethod.fileDownload(dirpath, filename, "xml");
		check = serverControlMethod.fileDownload(dirpath, imagename, "profile");
		check = serverControlMethod.fileDownload(dirpath, themename, "theme");
		check = serverControlMethod.fileDownload(dirpath, paintname, "paint");

		view_other_profile = true;
		checkprofile = 2;
		LinearLayout profile = (LinearLayout) View.inflate(
				getApplicationContext(), R.layout.profile, null);

		setContentView(profile);
		otherName = p.getName();
		otherPhoneNumber = p.getNumber();

		init_profile_layout(p.getName(), p.getNumber());

	}

	public class CheckBoxListener implements OnClickListener {
		List<Person> persons;
		int position;
		PersonAdapter p;

		CheckBoxListener(List<Person> persons, int position, PersonAdapter p) {
			this.persons = persons;
			this.position = position;
			this.p = p;
		}

		@Override
		public void onClick(View v) {

			persons.get(position).check();
			p.notifyDataSetChanged();
		}
	}

	private class GroupAdapter extends BaseAdapter {
		Context context;
		LayoutInflater inflater;
		ArrayList<Group> groups = null;

		public GroupAdapter(Context context, ArrayList<Group> groups) {
			this.context = context;
			this.groups = groups;
			inflater = LayoutInflater.from(this.context);
		}

		@Override
		public int getCount() {

			return groups.size();
		}

		@Override
		public Object getItem(int position) {
			return groups.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {

			View groupView = convertView;
			if (groupView == null) {
				groupView = inflater.inflate(R.layout.group_list_item, null);
			}
			final ImageView group_unfold = (ImageView) groupView
					.findViewById(R.id.group_unfold);
			final ImageView group_fold = (ImageView) groupView
					.findViewById(R.id.group_fold);
			group_add_button = (ImageView) groupView
					.findViewById(R.id.group_addimage);
			TextView group_name = (TextView) groupView
					.findViewById(R.id.group_name);
			group_name.setTypeface(font);
			TextView number_of_group_member = (TextView) groupView
					.findViewById(R.id.number_of_group_member);
			number_of_group_member.setTypeface(font);
			final ListView group_member_list = (ListView) groupView
					.findViewById(R.id.group_member_list);

			PersonInGroupAdapter adapter = new PersonInGroupAdapter(
					getApplicationContext(), groups.get(position).getMember());
			group_member_list.setAdapter(adapter);

			if (commit) {
				android.widget.LinearLayout.LayoutParams params = new android.widget.LinearLayout.LayoutParams(
						LayoutParams.MATCH_PARENT, DpToPixel(groups
								.get(position).getMember().size() * 61));
				group_member_list.setLayoutParams(params);
				commit = false;
			}

			group_unfold.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {

					android.widget.LinearLayout.LayoutParams params = new android.widget.LinearLayout.LayoutParams(
							LayoutParams.MATCH_PARENT, DpToPixel(groups
									.get(position).getMember().size() * 61));
					group_member_list.setLayoutParams(params);

					group_member_list.setVisibility(View.VISIBLE);
					group_unfold.setVisibility(View.GONE);
					group_fold.setVisibility(View.VISIBLE);

					params = new android.widget.LinearLayout.LayoutParams(
							LayoutParams.MATCH_PARENT,
							LayoutParams.MATCH_PARENT);
					groupList.setLayoutParams(params);

					notifyDataSetChanged();

				}
			});

			android.widget.LinearLayout.LayoutParams params = new android.widget.LinearLayout.LayoutParams(
					LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
			groupList.setLayoutParams(params);

			group_fold.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					android.widget.LinearLayout.LayoutParams params = new android.widget.LinearLayout.LayoutParams(
							LayoutParams.MATCH_PARENT, 0);
					group_member_list.setLayoutParams(params);

					group_member_list.setVisibility(View.GONE);
					group_unfold.setVisibility(View.VISIBLE);
					group_fold.setVisibility(View.GONE);
					// TODO

					params = new android.widget.LinearLayout.LayoutParams(
							LayoutParams.MATCH_PARENT, DpToPixel(groupArray
									.size() * 65));
					groupList.setLayoutParams(params);

					notifyDataSetChanged();
				}
			});

			group_name.setText(groups.get(position).getName());
			number_of_group_member.setText("( "
					+ (groups.get(position).getNumberOfMember()) + " )");

			group_add_button.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {

					PersonAdapter personAdapter = new PersonAdapter(
							getApplicationContext(), personArray, groups
									.get(position));
					addPerson = true;
					personAddList.setAdapter(personAdapter);
					personAddList.setVisibility(View.VISIBLE);
					commitButton.setVisibility(View.VISIBLE);
					groupPanel_groupAddButton.setVisibility(View.GONE);
				}
			});

			return groupView;
		}
	}

	private class PersonInGroupAdapter extends BaseAdapter {
		Context context;
		LayoutInflater inflater;
		Vector<Person> persons = null;

		public PersonInGroupAdapter(Context context, Vector<Person> persons) {
			this.context = context;
			inflater = LayoutInflater.from(this.context);
			this.persons = persons;

			for (int i = 0; i < this.persons.size(); i++) {
				if (this.persons.get(i).getName().equals("null")
						&& this.persons.get(i).getNumber().equals("null")) {
					this.persons.remove(i);
				}
			}
		}

		@Override
		public int getCount() {
			return persons.size();
		}

		@Override
		public Object getItem(int position) {
			return persons.get(position);
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View person = convertView;
			Person p = persons.get(position);

			if (person == null) {
				person = inflater.inflate(R.layout.view_friend_list, null);
			}
			TextView nameText = (TextView) person.findViewById(R.id.name);
			nameText.setTypeface(font);
			nameText.setTextColor(Color.BLACK);
			ImageView profileImageView = (ImageView) person
					.findViewById(R.id.view_friend_list_image);
			ImageView buttonCall = (ImageView) person
					.findViewById(R.id.buttonCall);
			ImageView check_on = (ImageView) person
					.findViewById(R.id.check_off);
			ImageView check_off = (ImageView) person
					.findViewById(R.id.check_on);

			// groupAdapter.notifyDataSetChanged();

			nameText.setText(p.getName().toString());

			if (p != null) {
				File myProfileImage = new File("/storage/emulated/0/data/info/"
						+ p.getNumber() + ".jpg");

				if (!myProfileImage.exists()) {
					profileImageView.setImageResource(R.drawable.noimage);
				} else {
					Uri myProfileImageUri = Uri.fromFile(myProfileImage);
					Bitmap circleImageBitmap = uriToBitmap(myProfileImageUri);
					profileImageView.setImageBitmap(circleImageBitmap);
				}
			}
			buttonCall.setOnClickListener(new CallButtonListener(p));

			return person;
		}

	}

	private class PersonAdapter extends BaseAdapter {
		Context mContext;
		LayoutInflater inflater;
		List<Person> persons = null;
		ArrayList<Person> arraylist;
		ArrayList<Person> addPerson;

		public PersonAdapter(Context context, ArrayList<Person> persons,
				final Group group) {

			this.persons = persons;
			inflater = LayoutInflater.from(context);

			addPerson = persons;

			for (int i = 0; i < addPerson.size(); i++) {
				addPerson.get(i).init_check();
			}

			for (int i = 0; i < addPerson.size(); i++) {
				for (int j = 0; j < group.getMember().size(); j++) {
					if (addPerson.get(i).getName()
							.equals(group.getMember().get(j).getName())
							&& addPerson
									.get(i)
									.getNumber()
									.equals(group.getMember().get(j)
											.getNumber())) {
						addPerson.get(i).check();
					}
				}
			}

			commitButton.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					group.getMember().clear();
					for (int i = 0; i < personArray.size(); i++) {
						if (personArray.get(i).isChecked()) {
							group.addMember(personArray.get(i));
						}
					}
					createGroupXML(dirPath);

					personAddList.setVisibility(View.GONE);
					commitButton.setVisibility(View.GONE);
					groupPanel_groupAddButton.setVisibility(View.VISIBLE);
					groupAdapter.notifyDataSetChanged();

					commit = true;

				}
			});

		}

		public PersonAdapter(Context context, List<Person> persons) {
			mContext = context;
			this.persons = persons;
			inflater = LayoutInflater.from(mContext);
			this.arraylist = new ArrayList<Person>();
			this.arraylist.addAll(persons);

		}

		public class ViewHolder {
			TextView nameText;
			ImageView profileImageView;
			ImageView buttonCall;
			ImageView check_on;
			ImageView check_off;
		}

		@Override
		public View getView(final int position, View convertView,
				ViewGroup parent) {
			ViewHolder holder;
			View v = convertView;
			Person p = persons.get(position);

			holder = new ViewHolder();

			if (v == null) {
				v = inflater.inflate(R.layout.view_friend_list, null);

				holder.nameText = (TextView) v.findViewById(R.id.name);
				holder.nameText.setTypeface(font);
				holder.nameText.setTextColor(Color.BLACK);
				holder.profileImageView = (ImageView) v
						.findViewById(R.id.view_friend_list_image);
				holder.buttonCall = (ImageView) v.findViewById(R.id.buttonCall);
				holder.check_off = (ImageView) v.findViewById(R.id.check_off);
				holder.check_on = (ImageView) v.findViewById(R.id.check_on);

				v.setTag(holder);
			} else {
				holder = (ViewHolder) v.getTag();
			}
			if (parent.getId() == R.id.addPersonList) {

				holder.buttonCall.setVisibility(View.GONE);

				if (p.isChecked()) {
					holder.check_on.setVisibility(View.VISIBLE);
					holder.check_off.setVisibility(View.GONE);
				} else {
					holder.check_off.setVisibility(View.VISIBLE);
					holder.check_on.setVisibility(View.GONE);
				}
			}
			CheckBoxListener checkBoxListener = new CheckBoxListener(persons,
					position, this);
			holder.check_on.setOnClickListener(checkBoxListener);
			holder.check_off.setOnClickListener(checkBoxListener);

			if (p != null) {
				File myProfileImage = new File("/storage/emulated/0/data/info/"
						+ p.getNumber() + ".jpg");

				if (!myProfileImage.exists()) {
					holder.profileImageView
							.setImageResource(R.drawable.noimage);
				} else {
					Uri myProfileImageUri = Uri.fromFile(myProfileImage);
					Bitmap circleImageBitmap = uriToBitmap(myProfileImageUri);
					holder.profileImageView.setImageBitmap(circleImageBitmap);
				}

				holder.buttonCall.setOnClickListener(new CallButtonListener(p));
				holder.nameText.setText(p.getName());
			}

			return v;
		}

		// Filter Class
		public void filter(String charText) {
			charText = charText.toLowerCase(Locale.getDefault());
			persons.clear();
			if (charText.length() == 0) {
				persons.addAll(arraylist);
			} else {
				for (Person wp : arraylist) {
					// if (wp.getName().toLowerCase(Locale.getDefault())
					// .contains(charText)) {
					// 초성 검색조건
					if (SoundSearcher.matchString(wp.getName(), charText)) {
						persons.add(wp);
					}
				}
			}
			notifyDataSetChanged();

		}

		@Override
		public int getCount() {

			return persons.size();
		}

		@Override
		public Person getItem(int position) {

			return persons.get(position);
		}

		@Override
		public long getItemId(int position) {

			return position;
		}
	}

	public Bitmap uriToBitmap(Uri uri) {

		// uri->bitmap 변경
		Bitmap myProfileImageBitmap;
		Bitmap myProfileImageBitmapCircle = null;
		MakeImageViewCircle mivc = new MakeImageViewCircle();

		try {
			myProfileImageBitmap = Images.Media.getBitmap(getContentResolver(),
					uri);
			myProfileImageBitmapCircle = mivc
					.setRoundCorner(myProfileImageBitmap);
			return myProfileImageBitmapCircle;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return myProfileImageBitmapCircle;
		} catch (IOException e) {

			e.printStackTrace();
			return myProfileImageBitmapCircle;
		}

	}

	private void call(String num) {
		try {
			Intent callIntent = new Intent(Intent.ACTION_CALL);
			callIntent.setData(Uri.parse("tel:" + num));
			this.startActivity(callIntent);

		} catch (ActivityNotFoundException e) {

		}

	}

	class PersonLayoutImageListener implements View.OnClickListener {
		String phonenumber;

		public PersonLayoutImageListener() {
			super();
		}

		public PersonLayoutImageListener(String phonenumber) {
			this.phonenumber = phonenumber;
		}

		@Override
		public void onClick(View v) {
			view_my_profile = false;
			view_other_profile = false;
			if (checkprofile == 1)
				view_my_picture = true;
			else if (checkprofile == 2)
				view_other_picture = true;
			setContentView(R.layout.picture);
			ImageView picture;
			try {
				picture = (ImageView) findViewById(R.id.picture);
				String imgpath = "/storage/emulated/0/data/info/" + phonenumber
						+ ".jpg";
				Bitmap bm = BitmapFactory.decodeFile(imgpath);
				picture.setImageBitmap(bm);
			} catch (Exception e) {
			}

		}

	}

	class CallButtonListener implements View.OnClickListener {
		Person p;

		public CallButtonListener() {
			super();
		}

		public CallButtonListener(Person p) {
			this.p = p;
		}

		@Override
		public void onClick(View v) {
			call(p.getNumber());

		}

	}

	class KakaoButtonListener implements View.OnClickListener {
		Person p;

		ElementReader elementReader = new ElementReader(myPhoneNumber);

		public KakaoButtonListener() {
			super();
		}

		@Override
		public void onClick(View v) {
			String msg = myName + "님의 프로필 입니다.";

			for (int i = 0; i < elementReader.profileItems_vector.size(); i++) {

				msg = msg
						+ "\r\n"
						+ String.format("%s : %s",
								elementReader.profileItems_vector.get(i)
										.getName(),
								elementReader.profileItems_vector.get(i)
										.getAttribute());
			}

			try {

				kakaoTalkLinkMessageBuilder.addImage(
						"https://s3-ap-northeast-1.amazonaws.com/piveapp/screenshot/"
								+ myPhoneNumber + "_info.png", 90, 160);
				kakaoTalkLinkMessageBuilder.addText(msg);
				kakaoTalkLinkMessageBuilder.addWebButton("pive홈페이지 접속",
						"http://dev.naver.com/projects/pive");

				kakaoLink.sendMessage(kakaoTalkLinkMessageBuilder.build(),
						MainActivity.this);
			} catch (KakaoParameterException e) {
				e.printStackTrace();
			}

		}
	}

	View.OnClickListener myQRCodeImageListener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			InputMethodManager imm = (InputMethodManager) v.getContext()
					.getSystemService(Context.INPUT_METHOD_SERVICE);
			// 감출 때
			imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
			view_qrcode = true;
			setContentView(R.layout.qr_image);
			qr_image = (ImageView) findViewById(R.id.qr_image);
			smsImage = (ImageView) findViewById(R.id.snsImage);

			File qrcodeImage = new File("/storage/emulated/0/data/info/"
					+ myPhoneNumber + ".png");
			if (!qrcodeImage.exists()) {
				qr_image.setImageResource(R.drawable.noqrcode);
			} else {
				Uri qrcodeUri = Uri.fromFile(qrcodeImage);
				qr_image.setImageURI(qrcodeUri);
			}
			ImageView backArrow = (ImageView) findViewById(R.id.my_picture_backarrow);
			backArrow.setOnClickListener(backArrow_listener);

			smsImage.setOnClickListener(sms_send_listener);

			if (dist[3] == 0) {
				LinearLayout infor3 = (LinearLayout) View.inflate(
						getApplicationContext(), R.layout.infor3, null);
				setContentView(infor3);
				infor3.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						onBackPressed();
					}
				});
				tutorial3 = true;
			}
			try {
				FileWriter fw = new FileWriter(
						"/storage/emulated/0/data/info/exp.txt");
				str_dist = "";
				dist[3] = 1;

				for (int i = 0; i < 4; i++) {
					str_dist += dist[i];
				}
				fw.write(str_dist);
				fw.flush();
				fw.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}

		}
	};

	// / profile 제작
	View.OnClickListener profile_modify_plusImageListener = new View.OnClickListener() {
		View grayView;

		@Override
		public void onClick(View v) {
			LinearLayout profile_modify_gray_view = (LinearLayout) findViewById(R.id.profile_modify_gray_view);
			grayView = findViewById(R.id.gray_view);

			grayView.setVisibility(View.VISIBLE);
			profile_modify_gray_view.setVisibility(View.VISIBLE);

			profile_modify_gray_view.setOnTouchListener(new OnTouchListener() {

				@Override
				public boolean onTouch(View v, MotionEvent event) {

					if (event.getAction() == MotionEvent.ACTION_DOWN) {

						float x = event.getX();
						float y = event.getY();

						addEditTextLayout.addEditText(x, y);
						v.setVisibility(View.GONE);
						grayView.setVisibility(View.GONE);
					}
					return true;
				}
			});

		}
	};

	// 사진 수정 AlertDialog
	View.OnClickListener profilePciture_listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			DialogInterface.OnClickListener albumListener = new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					doTakeAlbumAction();
				}
			};

			DialogInterface.OnClickListener cancelListener = new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			};

			try {
				new AlertDialog.Builder(MainActivity.this)
						.setTitle("프로필 사진을 바꾸시겠습니까?")
						.setNeutralButton("앨범검색", albumListener)
						.setNegativeButton("취소", cancelListener).show();
			} catch (Exception e) {
			}
		}
	};

	View.OnClickListener sms_send_listener = new View.OnClickListener() {
		@Override
		public void onClick(View v) {

			Intent intent = new Intent(Intent.ACTION_SEND);
			intent.setType("image/*");
			File file = new File(dirPath + "/" + myPhoneNumber + ".png");

			// File file = new
			// File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/abc.jpg");
			Uri uri = Uri.fromFile(file);
			intent.addCategory("android.intent.category.DEFAULT");
			intent.putExtra(Intent.EXTRA_STREAM, uri);
			startActivity(intent);
		}
	};

	Button.OnClickListener inputYoutubeId = new OnClickListener() {

		public void onClick(View v) {
			AlertDialog.Builder alert = new AlertDialog.Builder(
					MainActivity.this);

			alert.setTitle("유투브영상의 주소를 붙여넣어 주세요");
			// Set an EditText view to get user input
			final EditText input = new EditText(MainActivity.this);
			input.setTextSize(12);
			alert.setView(input);

			alert.setPositiveButton("Ok",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {
							if (input.getText().toString()
									.startsWith("https://youtu.be/")) {
								String youtubeaddress = input.getText()
										.toString();
								myYoutubeId = youtubeaddress.substring(17);
							} else if (input
									.getText()
									.toString()
									.startsWith(
											"https://m.youtube.com/watch?v=")) {
								String youtubeaddress = input.getText()
										.toString();
								myYoutubeId = youtubeaddress.substring(30);
							} else if (input
									.getText()
									.toString()
									.startsWith(
											"https://www.youtube.com/watch?v=")) {
								String youtubeaddress = input.getText()
										.toString();
								myYoutubeId = youtubeaddress.substring(32);
							} else {
								myYoutubeId = "";
							}
						}
					});

			alert.setNegativeButton("Cancel",
					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog,
								int whichButton) {
							// Canceled.
						}
					});

			alert.show();
		}

	};

	public class MoveLotation {
		LayoutParams params;

		MoveLotation() {

		}

		public LayoutParams getParams(int x, int y) {

			params = new LayoutParams(
					android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
					android.view.ViewGroup.LayoutParams.WRAP_CONTENT);

			params.setMargins(x, y, 0, 0);

			return params;
		}
	}

	public class AddEditTextLayout {// TODO

		public int DpToPixel(float dp) {
			return (int) (dp * (getApplicationContext().getResources()
					.getDisplayMetrics().densityDpi / 160f));
		}

		public EditText[] makeEditText() {
			int hintColor = getHintTextColor(myPhoneNumber);
			EditText[] array_editText = new EditText[2];

			for (int i = 0; i < array_editText.length; i++) {
				array_editText[i] = new EditText(getApplicationContext());
				array_editText[i].setTextColor(Color.GRAY);
				array_editText[i].setPadding(DpToPixel(3), DpToPixel(3),
						DpToPixel(3), DpToPixel(3));
				array_editText[i].setTextSize(DpToPixel(7));

			}
			array_editText[0].setHint("name");// TODO
			array_editText[0].setHintTextColor(hintColor);
			array_editText[1].setHint("attribute");
			array_editText[1].setHintTextColor(hintColor);
			vector_EditText.add(array_editText);

			return vector_EditText.lastElement();
		}

		public LayoutParams get_InitParams(float x, float y) {

			LayoutParams array_params = new LayoutParams(
					android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
					android.view.ViewGroup.LayoutParams.WRAP_CONTENT);

			array_params.alignWithParent = true;
			array_params.setMargins((int) x, (int) y, 0, 0);

			return array_params;
		}

		public LinearLayout makeEditTextLayout() {
			EditText[] array_editText = new EditText[2];
			LinearLayout editTextLayout = new LinearLayout(
					getApplicationContext());
			ImageView circle = new ImageView(getApplicationContext());

			circle.setBackground(getResources().getDrawable(R.drawable.circle));
			array_editText = makeEditText();

			editTextLayout.addView(circle);

			for (int i = 0; i < array_editText.length; i++)
				editTextLayout.addView(array_editText[i]);

			return editTextLayout;
		}

		public void addEditText(float x, float y) {

			LayoutParams params;

			vector_EditTextLayout.add(makeEditTextLayout());

			params = get_InitParams(x, y);

			vector_EditTextLayout.lastElement()
					.setOnTouchListener(
							new LayoutTouchListener(vector_EditTextLayout
									.lastElement()));

			detail_modify_profile.addView(vector_EditTextLayout.lastElement(),
					params);
		}
	}

	class LayoutTouchListener implements OnTouchListener {
		LinearLayout editTextLayout;
		MoveLotation moveLotation;;

		public LayoutTouchListener() {

		}

		public LayoutTouchListener(LinearLayout editTextLayout) {
			this.editTextLayout = editTextLayout;
			moveLotation = new MoveLotation();
			trash = (ImageView) findViewById(R.id.trash);
		}

		@Override
		public boolean onTouch(View v, MotionEvent event) {
			if (event.getAction() == MotionEvent.ACTION_MOVE) {
				editTextLayout.setLayoutParams(moveLotation.getParams(
						(int) (event.getX() + editTextLayout.getX() - 20),
						(int) (event.getY() + editTextLayout.getY() - 45)));

			}

			if (event.getAction() == MotionEvent.ACTION_UP) {
				if (editTextLayout.getX() >= trash.getX()
						&& editTextLayout.getY() >= trash.getY()) {

					int index = vector_EditTextLayout.indexOf(editTextLayout);
					vector_EditText.remove(index);
					vector_EditTextLayout.remove(editTextLayout);

					editTextLayout.setVisibility(View.GONE);
				} else {
					editTextLayout
							.setLayoutParams(moveLotation.getParams(
									(int) (event.getX() + editTextLayout.getX() - 20) / 10 * 10,
									(int) (event.getY() + editTextLayout.getY() - 45) / 10 * 10));
				}
			}
			return true;
		}
	}

	// -------------------------------------------------------------

	// ---------------------사진 수정 부분 ---------------------//
	private void doTakeAlbumAction() {
		// 앨범 호출
		Intent intent = new Intent(Intent.ACTION_PICK);
		intent.setType(android.provider.MediaStore.Images.Media.CONTENT_TYPE);
		onDoTake = true;
		startActivityForResult(intent, PICK_FROM_ALBUM);

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK) {
			onDoTake = false;
			onQr = false;
			return;
		}
		if (onDoTake) {

			switch (requestCode) {
			case CROP_FROM_CAMERA: {
				final Bundle extras = data.getExtras();
				String dirPath = "/storage/emulated/0/data/info";
				File file = new File(dirPath);

				if (!file.exists()) {
					file.mkdirs();
				}

				if (extras != null) {
					photo = extras.getParcelable("data");

					profilePciture.setImageBitmap(photo);
				}

				// 임시 파일 삭제
				File f = new File(mImageCaptureUri.getPath());
				if (f.exists()) {
					f.delete();
				}

				onDoTake = false;
				break;

			}

			case PICK_FROM_ALBUM: {
				// 이후의 처리가 카메라와 같으므로 일단 break없이 진행합니다.
				mImageCaptureUri = data.getData();
				Intent intent = new Intent("com.android.camera.action.CROP");
				intent.setDataAndType(mImageCaptureUri, "image/*");

				intent.putExtra("outputX", 300);
				intent.putExtra("outputY", 300);
				intent.putExtra("scale", true);
				intent.putExtra("return-data", true);
				startActivityForResult(intent, CROP_FROM_CAMERA);

				break;
			}
			}

		}

		if (onQr) {
			setContentView(R.layout.web);
			openWeb = true;
			String contents = data.getStringExtra("SCAN_RESULT");
			String format = data.getStringExtra("SCAN_RESULT_FORMAT");
			WebView webview = (WebView) findViewById(R.id.webview);
			webview.setWebViewClient(new WebViewClient());
			WebSettings set = webview.getSettings();
			set.setJavaScriptEnabled(true);
			set.setBuiltInZoomControls(true);
			set.setUseWideViewPort(true);
			set.setLoadWithOverviewMode(true);

			webview.loadUrl(contents);
			onBackPressed();
			onQr = false;
		}
	}

	// 프로필 캡쳐 부분
	public class testScreen extends AsyncTask<Void, Void, Void> {

		@Override
		protected Void doInBackground(Void... params) {

			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			try {
				FrameLayout profileLayout = (FrameLayout) findViewById(R.id.profile_alllayout);
				profileLayout.setDrawingCacheEnabled(true);

				Bitmap screenshot = profileLayout.getDrawingCache();
				infofilename = myPhoneNumber + "_info.png";

				try {
					File f = new File("/storage/emulated/0/data/info",
							infofilename);
					if (f.exists()) {
						f.delete();
					}
					f.createNewFile();
					OutputStream outStream = new FileOutputStream(f);
					screenshot.compress(Bitmap.CompressFormat.PNG, 100,
							outStream);
					outStream.close();
				} catch (IOException e) {

					e.printStackTrace();

				}
				profileLayout.setDrawingCacheEnabled(false);

			} catch (Exception e) {
			}
			return null;
		}

		@Override
		protected void onPostExecute(Void result) {
			boolean check = serverControlMethod.fileUpload(dirPath, "/"
					+ infofilename, "screenshot");

			captureProfileState = false;
		}
	}

	private class LoadQr extends AsyncTask<String, String, Bitmap> {

		Bitmap bitmap;

		@Override
		protected Bitmap doInBackground(String... args) {
			try {
				bitmap = BitmapFactory.decodeStream((InputStream) new URL(
						args[0]).getContent());
			} catch (Exception e) {
				e.printStackTrace();
			}
			return bitmap;
		}

		protected void onPostExecute(Bitmap image) {
			if (image != null) {
				qr_image.setImageBitmap(image);
			}
		}

	}

}