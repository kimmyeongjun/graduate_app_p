package com.example.pive;

import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

public class LoginActivity extends Activity {
	
	public Vector<Person> personVector;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(com.example.pive.R.layout.login);

			personVector = new Vector<Person>();
		
		Map<String, String> phone_address = ContactUtil.getAddressBook(this);

		@SuppressWarnings("rawtypes")
		Iterator ite = HashSort.sortByValue(phone_address).iterator();
		while (ite.hasNext()) {
			String phoneNumber = ite.next().toString();
			String name = phone_address.get(phoneNumber).toString();
			personVector.add(new Person(name, phoneNumber));
		}
		for(int i = 0 ; i < personVector.size() ; i ++)
			System.out.println(personVector.get(i).getNumber());
		
		//TODO 동기화
/*		
		ServerControlMethod serverControlMethod = new ServerControlMethod();
		boolean result = serverControlMethod.allFileDownload("/storage/emulated/0/data/info", personVector);
		//*/
	}
	protected void setBackground(Drawable drawable) {
		final View root = findViewById(android.R.id.content);
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
			root.setBackground(drawable);
		} else {
			root.setBackgroundDrawable(drawable);
		}
	}
}

