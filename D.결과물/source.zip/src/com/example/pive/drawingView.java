package com.example.pive;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;

public class drawingView extends View {

	private static ArrayList<Vertex> arVertex = new ArrayList<Vertex>();;
	private Paint mPaint;
	private static boolean init = true;
	private static boolean able = false;
	private static boolean remove = false;
	private static boolean initCanvas = false;
	private static int penColor = 0;
	private static int penSize = 7;
	private static int beforeColor = 0;
	
	public drawingView(Context context) {
		super(context);

		mPaint = new Paint();
		mPaint.setAntiAlias(true);
	}

	public drawingView(Context context, AttributeSet atts) {
		super(context);
		mPaint = new Paint();
		mPaint.setAntiAlias(true);		
	}

	public class Vertex {
		float x;
		float y;
		boolean draw;
		int color;
		int size;

		public Vertex(float x, float y, boolean draw, int penColor, int penSize) {
			this.x = x;
			this.y = y;
			this.draw = draw;
			this.color = penColor;
			this.size = penSize;
		}
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if (init) {
			canvas.drawColor(0x00000000);
			arVertex.clear();
			init = false;
			remove = false;
			initCanvas = false;
			penSize = 7;
			penColor = 0;
			beforeColor = 0;
		}
		for (int i = 0; i < arVertex.size(); i++) {
			switch (arVertex.get(i).color) {
			case 0:
				mPaint.setColor(Color.BLACK);
				break;
			case 1:
				mPaint.setColor(Color.WHITE);
				break;
			case 2:
				mPaint.setColor(Color.RED);
				break;
			case 3:
				mPaint.setColor(Color.BLUE);
				break;
			case 4:
				mPaint.setColor(Color.GREEN);
				break;
			case 5:
				mPaint.setColor(Color.YELLOW);
				break;
			}
			mPaint.setStrokeWidth(arVertex.get(i).size);
			if(arVertex.get(i).color == -1) {
				
			}
			else if (arVertex.get(i).draw) {
				canvas.drawLine(arVertex.get(i - 1).x, arVertex.get(i - 1).y,
						arVertex.get(i).x, arVertex.get(i).y, mPaint);
			} else {
				canvas.drawPoint(arVertex.get(i).x, arVertex.get(i).y, mPaint);
			}
		}
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		if (able) {
			if(initCanvas) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					arVertexClear();
					try {
					MainActivity.modifyPaintBackgruoud.setBackgroundResource(R.drawable.nopaint);
					} catch(Exception e) {	}
					invalidate();
					break;
				case MotionEvent.ACTION_MOVE:
					break;
				case MotionEvent.ACTION_UP:
					initCanvas = false;
					break;
				}				
				return true;
			} else if(remove) {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					for(int i=0;i<arVertex.size();i++) {
						if(arVertex.get(i).x > event.getX()-50 
								&& arVertex.get(i).x <= event.getX()+50 
								&& arVertex.get(i).y > event.getY()-50 
								&& arVertex.get(i).y <= event.getY()+50 ) {
							arVertex.get(i).color = -1;
						}
					}
					break;
				case MotionEvent.ACTION_MOVE:
					for(int i=0;i<arVertex.size();i++) {
						if(arVertex.get(i).x > event.getX()-50 
								&& arVertex.get(i).x <= event.getX()+50 
								&& arVertex.get(i).y > event.getY()-50 
								&& arVertex.get(i).y <= event.getY()+50 ) {
							arVertex.get(i).color = -1;
						}
					}
					break;
				}
				invalidate();
				return true;
			} else {
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					arVertex.add(new Vertex(event.getX(), event.getY(), false,
							penColor, penSize));
					break;
				case MotionEvent.ACTION_MOVE:
					arVertex.add(new Vertex(event.getX(), event.getY(), true,
							penColor, penSize));
					break;
				}
				invalidate();
				return true;
			}
		}
		return false;
	}

	public static void initCanvas() {
		able = false;
		init = true;
	}

	public static void setPaintAble() {
		if (able)
			able = false;
		else
			able = true;
	}
	public static void initPaintAble() {
		able = false;
	}

	public static void setPenColor(int colorNum) {
		penColor = colorNum;
		if(remove) {
			beforeColor = colorNum;
		}
	}

	public static void setPenSize(int SizeNum) {
		penSize = SizeNum;
	}

	public static void setRemove() {
		if(remove){
			penColor = beforeColor;
			beforeColor = 0;
			remove = false;
		} else {
			beforeColor = penColor;
			penColor = -1;
			remove = true;
		}
	}
	public static void setInitCanvas() {
		if(initCanvas){
			initCanvas = false;
		} else {
			initCanvas = true;
		}
	}
	public static boolean isAble() {
		return able;
	}
	public static boolean isRemove() {
		return remove;
	}
	public static boolean isinitCanvas() {
		return initCanvas;
	}
	public static void arVertexClear() {
		arVertex.clear();
	}
}
