package com.example.pive;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import android.content.Context;

public class Infor {
	int dist[] = { 0, 0, 0, 0};

	public int[] load(int[] dist) throws FileNotFoundException {
		File myname = new File("/storage/emulated/0/data/info/exp.txt");
		FileReader reader = new FileReader(myname);
		try {
			for (int i = 0; i < 4; i++) {
				dist[i] = reader.read()-48;
				System.out.println(dist[i]);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return dist;
		
	}
	
	public void judge(){
		
	}
}
