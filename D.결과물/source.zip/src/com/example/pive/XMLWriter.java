package com.example.pive;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class XMLWriter {
	String myPhoneNumber;

	XMLWriter() {

	}

	public static void Open(String path, String phoneNumber,String youtubeId) {
		FileOutputStream fo = null;

		File file = new File(path);
		if (!file.exists()) {
			file.mkdirs();
			// Toast.makeText(getApplicationContext(), "Success",
			// Toast.LENGTH_SHORT).show();
		}
		String fileName = "/" + phoneNumber + ".xml";
		File savefile = new File(path + fileName);
		
		if (youtubeId.equals("")) {
			youtubeId = "null";
		}
		
		try {
			fo = new FileOutputStream(savefile);
			String open = "<?xml version='1.0' encoding='UTF-8' ?>";
			String openProfileItems = "<profileItems>";
			String openDetail_profile = "<detail_profile>";
			String openVideo = "<video>";
			String videourl = "<videoURL URL = \"" + youtubeId + "\"></videoURL>";
			String closeVideo = "</video>";

			String enter = "\r\n";
			fo.write(open.getBytes());
			fo.write(enter.getBytes());
			fo.write(openDetail_profile.getBytes());
			fo.write(enter.getBytes());
			fo.write(openVideo.getBytes());
			fo.write(enter.getBytes());
			fo.write(videourl.getBytes());
			fo.write(enter.getBytes());
			fo.write(closeVideo.getBytes());
			fo.write(enter.getBytes());
			
			fo.write(enter.getBytes());
			
			fo.write(enter.getBytes());
			fo.write(openProfileItems.getBytes());

			fo.write(enter.getBytes());
			fo.write(enter.getBytes());

			fo.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("open");

	}

	public static void close(String path, String phoneNumber) {
		FileOutputStream fo = null;

		File savefile = new File(path + "/" + phoneNumber + ".xml");
		try {
			fo = new FileOutputStream(savefile, true);
			String close2 = "</profileItems>";
			String close = "</detail_profile>";
			String enter = "\r\n";
			fo.write(enter.getBytes());
			fo.write(close2.getBytes());

			fo.write(enter.getBytes());
			fo.write(close.getBytes());

			fo.close();
		} catch (IOException e) {

			e.printStackTrace();
		}
		System.out.println("close");
	}

	public static void profileItemObjWriter(String name, String attribute,
			int x, int y, String path, String phoneNumber) {
		File savefile = new File(path + "/" + phoneNumber + ".xml");
		FileOutputStream fo = null;
		try {
			fo = new FileOutputStream(savefile, true);

			String line = "<profileItemObj name = \"" + name
					+ "\" attribute = \"" + attribute + "\"  x=\"" + x
					+ "\" y=\"" + y + "\"></profileItemObj>";
			String enter = "\r\n";

			fo.write(line.getBytes());
			fo.write(enter.getBytes());

			fo.close();
		} catch (IOException e) {
			System.out.println("");
		}
		System.out.println("line");
	}

}