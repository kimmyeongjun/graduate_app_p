package com.example.pive;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;

public class IntroActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		LinearLayout intro = (LinearLayout) View.inflate(
				getApplicationContext(), R.layout.start, null);
		setContentView(intro);

		Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
			public void run() {
				Intent intent = new Intent(IntroActivity.this,
						MainActivity.class);
				startActivity(intent);
				finish();
			}
		}, 500);
	}
}
