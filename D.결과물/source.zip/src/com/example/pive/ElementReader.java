package com.example.pive;

import java.util.ArrayList;
import java.util.Vector;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ElementReader {
	public Vector<Profile> profileItems_vector;

	String dirPath = "/storage/emulated/0/data/info";
	String fileName;
	XMLReader xml;
	Node ProfileNode;
	
	public String videoURL;

	public ArrayList<Group> groupArray;
	Node GroupNode;
	boolean exist = false;

	public ElementReader() {
		fileName = "/groups.xml";
		xml = new XMLReader(dirPath + fileName);

		GroupNode = xml.getGroupElement();

		groupArray = new ArrayList<Group>();

		Node groupNode = XMLReader.getNode(GroupNode, XMLReader.E_GROUPOBJ);
		NodeList groupNodeList = groupNode.getChildNodes();

		for (int i = 0; i < groupNodeList.getLength(); i++) {
			Node node = groupNodeList.item(i);
			if (node.getNodeName().equals(XMLReader.E_MEMBER)) {
				String groupname = XMLReader.getAttr(node, "groupName");
				String name = XMLReader.getAttr(node, "name");
				String phonenumber = XMLReader.getAttr(node, "phoneNumber");

				int index = 0;
				for (int j = 0; j < groupArray.size(); j++) {
					if (groupname.equals(groupArray.get(j).getName())) {
						exist = true;
						index = j;
						break;
					}
				}
				if (!exist) {
					Group group = new Group(groupname);
					group.addMember(new Person(name, phonenumber));
					groupArray.add(group);
				} else {
					groupArray.get(index).addMember(
							new Person(name, phonenumber));
				}
			}
			exist = false;
		}

	}

	public ElementReader(String phoneNumber) {
		fileName = "/" + phoneNumber + ".xml";
		xml = new XMLReader(dirPath + fileName);
		ProfileNode = xml.getProfileElement();

		profileItems_vector = new Vector<Profile>();

		Node pfNode = XMLReader.getNode(ProfileNode, XMLReader.E_PROFILE);

		NodeList profileNodeList = pfNode.getChildNodes();
		for (int i = 0; i < profileNodeList.getLength(); i++) {
			Node node = profileNodeList.item(i);
			if (node.getNodeType() != Node.ELEMENT_NODE)
				continue;
			// found!!, <Obj> tag

			if (node.getNodeName().equals(XMLReader.E_PROFILEITEMOBJ)) {
				String name = XMLReader.getAttr(node, "name");
				String attribute = XMLReader.getAttr(node, "attribute");
				int x = Integer.parseInt(XMLReader.getAttr(node, "x"));
				int y = Integer.parseInt(XMLReader.getAttr(node, "y"));

				Profile profile = new Profile(name, attribute, x, y);
				try {
					profileItems_vector.add(profile);
				}

				catch (ArrayIndexOutOfBoundsException e) {
					e.printStackTrace();
				}
			}
		}
		
		Node videoNode = XMLReader.getNode(ProfileNode, XMLReader.E_VIDEO);
		Node videoURLNode = XMLReader.getNode(videoNode,XMLReader.E_VIDEOURL);
		videoURL = XMLReader.getAttr(videoURLNode, "URL");
		
		

	}
}
