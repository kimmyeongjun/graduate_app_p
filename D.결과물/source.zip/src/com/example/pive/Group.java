package com.example.pive;

import java.util.Vector;

public class Group {
	private String name;
	private Vector<Person> members = new Vector<Person>();

	public Group(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void addMember(Person person) {
		members.add(person);
	}

	public Vector<Person> getMember() {
		return members;
	}
	
	public int getNumberOfMember() {
		return members.size();
	}

}
