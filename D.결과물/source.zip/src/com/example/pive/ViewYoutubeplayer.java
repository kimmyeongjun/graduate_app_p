package com.example.pive;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerFragment;


public class ViewYoutubeplayer extends YouTubeFailureRecoveryActivity{
	private String videoId = "";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewyoutube);
		
		YouTubePlayerFragment youTubePlayerFragment =
		        (YouTubePlayerFragment) getFragmentManager().findFragmentById(R.id.youtube_fragment);
		youTubePlayerFragment.initialize(DEVELOPER_KEY, this);
		
		Intent intent = getIntent();
		
		videoId = intent.getStringExtra("YOUTUBEID");
	}
	
	@Override
	  public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer player,
	      boolean wasRestored) {
	    if (!wasRestored) {
	      player.cueVideo(videoId);
	    }
	  }
	//https://youtu.be/0t3nw6dB-hA
	  @Override
	  protected YouTubePlayer.Provider getYouTubePlayerProvider() {
	    return (YouTubePlayerFragment) getFragmentManager().findFragmentById(R.id.youtube_fragment);
	  }

}
