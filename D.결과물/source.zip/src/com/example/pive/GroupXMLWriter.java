package com.example.pive;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class GroupXMLWriter {

	String myPhoneNumber;

	GroupXMLWriter() {

	}

	public static void Open(String path) {
		FileOutputStream fo = null;

		File file = new File(path);
		if (!file.exists()) {
			file.mkdirs();
		}
		String fileName = "/groups.xml";
		File savefile = new File(path + fileName);
		try {
			fo = new FileOutputStream(savefile);
			String open = "<?xml version='1.0' encoding='UTF-8' ?>";
			String openGroup = "<group>";
			String openGroupObj = "<groupObj>";

			String enter = "\r\n";
			fo.write(open.getBytes());
			fo.write(enter.getBytes());
			fo.write(openGroup.getBytes());
			fo.write(enter.getBytes());

			fo.write(enter.getBytes());
			fo.write(openGroupObj.getBytes());

			fo.write(enter.getBytes());
			fo.write(enter.getBytes());

			fo.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void close(String path) {
		FileOutputStream fo = null;

		File savefile = new File(path + "/groups.xml");
		try {
			fo = new FileOutputStream(savefile, true);
			String close2 = "</groupObj>";
			String close = "</group>";
			String enter = "\r\n";
			fo.write(enter.getBytes());
			fo.write(close2.getBytes());

			fo.write(enter.getBytes());
			fo.write(close.getBytes());

			fo.close();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	public static void memberWriter(String groupName, String name,
			String phoneNumber, String path) {
		File savefile = new File(path + "/groups.xml");
		FileOutputStream fo = null;
		try {
			fo = new FileOutputStream(savefile, true);

			String line = "<member groupName = \"" + groupName + "\" name = \""
					+ name + "\"  phoneNumber=\"" + phoneNumber
					+ "\"></member>";
			String enter = "\r\n";

			fo.write(line.getBytes());
			fo.write(enter.getBytes());

			fo.close();
		} catch (IOException e) {
		}
	}

}
