/** Automatically generated file. DO NOT MODIFY */
package com.example.pive;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}