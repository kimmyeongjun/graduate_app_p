/** Automatically generated file. DO NOT MODIFY */
package com.kakao.sdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}